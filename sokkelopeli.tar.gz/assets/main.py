"""
╔══════════════════════════════════════════════╗
║             Sokkelo Peli                     ║
║  WASD/Nuolet = Liiku / Hyökkää               ║
║  E           = Inventaario                   ║
║  1-8         = Käytä esine                   ║
║  Hiiri       = Klikkaa UI-elementtejä        ║
╚══════════════════════════════════════════════╝
"""

import pygame, random, math, sys, os, json, struct, array as arr, asyncio

# ═══════════════════════════════════════════
#  VAKIOT
# ═══════════════════════════════════════════
SCREEN_W, SCREEN_H = 1200, 820
TILE      = 32
MAP_W     = 68
MAP_H     = 50
FPS       = 60
PANEL_W   = 240
GAME_W    = SCREEN_W - PANEL_W
GAME_H    = SCREEN_H - 56
VP_W      = GAME_W  // TILE
VP_H      = GAME_H  // TILE
SPRITE_DIR = "sprites"
SCORE_FILE = "highscores.json"

WALL=0; FLOOR=1; STAIRS=3; SHOP_TILE=4

# Väripaletti
P = {
    "bg":(8,6,14),"panel":(16,13,26),"panel2":(22,18,34),
    "border":(55,44,75),"text":(210,200,220),"dim":(95,85,108),
    "white":(255,255,255),"black":(0,0,0),
    "red":(220,65,65),"green":(55,200,80),"gold":(255,210,40),
    "blue":(55,120,240),"purple":(185,60,225),"cyan":(55,210,210),
    "orange":(235,130,40),"hp_hi":(55,200,80),"hp_mid":(230,180,40),
    "hp_lo":(210,60,60),"xp":(150,80,220),
}

# Kerrosteemat
MAX_FLOOR = 100
BOSS_FLOORS = set(range(5, 101, 5))

FLOOR_THEMES = {
    1:  {"name":"Luola",                "wall":(70,60,50),   "floor":(50,43,36),  "tint":None,             "fog":(0,0,0,115)},
    2:  {"name":"Katakombit",           "wall":(55,55,70),   "floor":(40,40,55),  "tint":(60,60,120,25),   "fog":(10,10,30,120)},
    3:  {"name":"Tulikanjoni",          "wall":(90,40,20),   "floor":(65,30,15),  "tint":(180,60,0,20),    "fog":(30,10,0,115)},
    4:  {"name":"Jääluola",             "wall":(60,80,110),  "floor":(45,60,85),  "tint":(0,80,160,18),    "fog":(0,20,50,120)},
    5:  {"name":"Ensimmäinen torni",    "wall":(80,20,20),   "floor":(55,15,15),  "tint":(120,0,0,30),     "fog":(20,0,0,120)},
    6:  {"name":"Hautausmaa",           "wall":(50,55,45),   "floor":(35,40,32),  "tint":(30,60,20,18),    "fog":(10,20,5,120)},
    7:  {"name":"Myrkkysoukko",         "wall":(40,70,30),   "floor":(28,55,20),  "tint":(20,100,10,22),   "fog":(0,30,0,115)},
    8:  {"name":"Demonin syvyys",       "wall":(100,25,25),  "floor":(70,18,18),  "tint":(150,20,0,25),    "fog":(30,5,0,120)},
    9:  {"name":"Aavekammio",           "wall":(55,45,80),   "floor":(40,32,62),  "tint":(50,20,120,20),   "fog":(15,5,40,120)},
    10: {"name":"Synnin palatsi",       "wall":(90,15,50),   "floor":(65,10,35),  "tint":(130,0,60,35),    "fog":(25,0,15,125)},
    11: {"name":"Sumulaakso",           "wall":(65,70,75),   "floor":(45,50,55),  "tint":(80,100,120,22),  "fog":(20,25,35,130)},
    12: {"name":"Kristalliontelo",      "wall":(50,40,90),   "floor":(35,28,70),  "tint":(60,40,180,20),   "fog":(10,5,50,120)},
    13: {"name":"Laavaaukeat",          "wall":(110,35,10),  "floor":(85,25,5),   "tint":(220,80,0,25),    "fog":(40,15,0,120)},
    14: {"name":"Hiilikammiot",         "wall":(35,35,40),   "floor":(25,25,28),  "tint":(20,20,30,15),    "fog":(5,5,10,125)},
    15: {"name":"Toinen torni",         "wall":(80,30,80),   "floor":(55,20,55),  "tint":(140,0,140,30),   "fog":(25,0,25,125)},
    16: {"name":"Lumiholvi",            "wall":(175,195,210),"floor":(140,160,180),"tint":(100,140,200,18),"fog":(30,40,70,120)},
    17: {"name":"Hiekkakatakombejä",    "wall":(130,105,50), "floor":(100,80,35), "tint":(160,120,40,18),  "fog":(35,25,5,115)},
    18: {"name":"Meriluola",            "wall":(30,60,90),   "floor":(20,45,70),  "tint":(0,60,120,22),    "fog":(0,15,35,120)},
    19: {"name":"Tuulen temppeli",      "wall":(90,110,95),  "floor":(65,80,68),  "tint":(50,120,60,18),   "fog":(10,25,12,115)},
    20: {"name":"Lohikäärmeen luola",   "wall":(110,25,10),  "floor":(80,18,8),   "tint":(180,30,0,30),    "fog":(40,8,0,125)},
    21: {"name":"Kielletty kaupunki",   "wall":(75,60,45),   "floor":(55,44,30),  "tint":(100,80,30,18),   "fog":(20,15,5,118)},
    22: {"name":"Varjomaailma",         "wall":(20,15,35),   "floor":(12,10,22),  "tint":(30,10,70,25),    "fog":(8,4,20,130)},
    23: {"name":"Tulinen katedrali",    "wall":(100,30,15),  "floor":(75,22,10),  "tint":(200,50,0,28),    "fog":(45,10,0,125)},
    24: {"name":"Kuunkammio",           "wall":(55,55,90),   "floor":(38,38,68),  "tint":(70,70,160,22),   "fog":(15,15,45,120)},
    25: {"name":"Kolmas torni",         "wall":(60,0,90),    "floor":(42,0,65),   "tint":(120,0,180,32),   "fog":(22,0,38,128)},
    26: {"name":"Helvetin solat",       "wall":(120,20,20),  "floor":(90,14,14),  "tint":(200,25,25,30),   "fog":(50,5,5,130)},
    27: {"name":"Kaaosmetsä",           "wall":(25,70,25),   "floor":(15,50,15),  "tint":(20,130,20,22),   "fog":(4,30,4,120)},
    28: {"name":"Tähtien tyrmä",        "wall":(25,20,60),   "floor":(15,12,45),  "tint":(40,30,130,25),   "fog":(8,6,35,128)},
    29: {"name":"Tuomion tasanko",      "wall":(105,15,60),  "floor":(78,10,44),  "tint":(160,0,80,30),    "fog":(32,0,18,130)},
    30: {"name":"Ikuisuuden sydän I",   "wall":(100,5,80),   "floor":(72,3,58),   "tint":(180,0,150,40),   "fog":(38,0,30,135)},
    31: {"name":"Suolaerämaa",          "wall":(200,185,160),"floor":(170,155,130),"tint":(220,200,150,15),"fog":(50,45,30,115)},
    32: {"name":"Kitkan luola",         "wall":(85,75,65),   "floor":(65,55,45),  "tint":(100,80,50,18),   "fog":(25,20,10,118)},
    33: {"name":"Kuparikaivos",         "wall":(130,75,30),  "floor":(100,58,22), "tint":(180,100,20,20),  "fog":(40,20,5,120)},
    34: {"name":"Obsidiaaniholvi",      "wall":(25,20,30),   "floor":(15,12,18),  "tint":(40,20,60,20),    "fog":(5,4,8,130)},
    35: {"name":"Neljäs torni",         "wall":(70,0,110),   "floor":(50,0,80),   "tint":(110,0,170,32),   "fog":(20,0,45,130)},
    36: {"name":"Medusan kammioit",     "wall":(45,90,60),   "floor":(30,68,45),  "tint":(30,120,50,22),   "fog":(8,28,12,122)},
    37: {"name":"Käärmeen syvyys",      "wall":(35,80,20),   "floor":(25,60,12),  "tint":(25,120,10,25),   "fog":(5,32,2,118)},
    38: {"name":"Savinen labyrintti",   "wall":(115,90,55),  "floor":(90,68,40),  "tint":(140,110,50,18),  "fog":(30,22,10,115)},
    39: {"name":"Verinen aavikko",      "wall":(130,30,20),  "floor":(100,20,15), "tint":(200,40,20,25),   "fog":(45,8,5,125)},
    40: {"name":"Titaanin linna",       "wall":(60,60,60),   "floor":(44,44,44),  "tint":(80,80,80,20),    "fog":(15,15,15,128)},
    41: {"name":"Kiehuvat suot",        "wall":(50,80,30),   "floor":(36,60,20),  "tint":(60,110,20,22),   "fog":(12,28,5,120)},
    42: {"name":"Fossiililuola",        "wall":(140,120,80), "floor":(110,92,60), "tint":(170,145,80,15),  "fog":(38,30,15,116)},
    43: {"name":"Sähköinen tyrmä",      "wall":(40,50,100),  "floor":(28,36,78),  "tint":(50,80,200,22),   "fog":(10,15,55,120)},
    44: {"name":"Pimeyden portit",      "wall":(18,12,28),   "floor":(10,7,16),   "tint":(25,10,55,28),    "fog":(5,3,15,135)},
    45: {"name":"Viides torni",         "wall":(50,0,130),   "floor":(36,0,95),   "tint":(90,0,200,35),    "fog":(18,0,55,132)},
    46: {"name":"Rikkinen laakso",      "wall":(110,100,20), "floor":(85,76,12),  "tint":(180,160,0,22),   "fog":(40,36,0,120)},
    47: {"name":"Kuollut kaupunki",     "wall":(60,58,55),   "floor":(44,42,40),  "tint":(70,65,55,15),    "fog":(15,14,12,120)},
    48: {"name":"Arktinen syvänne",     "wall":(180,210,230),"floor":(145,175,200),"tint":(120,170,220,20),"fog":(35,50,80,122)},
    49: {"name":"Kuun varjo",           "wall":(40,35,70),   "floor":(28,24,52),  "tint":(50,40,120,25),   "fog":(10,8,32,128)},
    50: {"name":"Demonikuningas",       "wall":(110,0,40),   "floor":(80,0,28),   "tint":(180,0,60,38),    "fog":(42,0,15,135)},
    51: {"name":"Jäätiköiden kammio",   "wall":(160,200,220),"floor":(130,168,190),"tint":(100,155,210,20),"fog":(28,45,75,120)},
    52: {"name":"Kivihirviön pesä",     "wall":(95,88,80),   "floor":(72,66,58),  "tint":(110,100,75,16),  "fog":(22,20,15,118)},
    53: {"name":"Magmavirran tunneli",  "wall":(120,40,5),   "floor":(92,28,3),   "tint":(230,70,0,28),    "fog":(48,14,0,125)},
    54: {"name":"Varjon labyrintti",    "wall":(22,16,38),   "floor":(14,10,24),  "tint":(35,14,72,28),    "fog":(6,4,18,132)},
    55: {"name":"Kuudes torni",         "wall":(40,0,150),   "floor":(28,0,108),  "tint":(80,0,220,38),    "fog":(16,0,62,135)},
    56: {"name":"Tulivuoren suoli",     "wall":(130,45,8),   "floor":(100,32,5),  "tint":(220,80,0,30),    "fog":(50,18,0,128)},
    57: {"name":"Safiiriontelo",        "wall":(20,40,110),  "floor":(12,28,82),  "tint":(30,60,200,25),   "fog":(6,12,52,122)},
    58: {"name":"Ikiroudan salat",      "wall":(145,175,195),"floor":(115,145,168),"tint":(90,140,200,22),"fog":(25,40,72,120)},
    59: {"name":"Verivirran solat",     "wall":(120,18,18),  "floor":(90,12,12),  "tint":(200,25,25,32),   "fog":(44,6,6,130)},
    60: {"name":"Seitsemäs torni",      "wall":(90,0,160),   "floor":(64,0,115),  "tint":(150,0,240,40),   "fog":(30,0,68,138)},
    61: {"name":"Kultakaivos",          "wall":(150,120,20), "floor":(118,92,12), "tint":(220,175,0,20),   "fog":(45,34,0,115)},
    62: {"name":"Salamantemppeli",      "wall":(30,45,110),  "floor":(20,32,84),  "tint":(45,80,220,25),   "fog":(8,15,58,122)},
    63: {"name":"Viidakon sydän",       "wall":(22,78,22),   "floor":(14,58,14),  "tint":(18,130,18,25),   "fog":(4,32,4,118)},
    64: {"name":"Kiteinen kammio",      "wall":(80,60,140),  "floor":(60,44,108), "tint":(120,80,220,22),  "fog":(22,14,55,125)},
    65: {"name":"Kahdeksas torni",      "wall":(120,0,180),  "floor":(86,0,130),  "tint":(190,0,255,42),   "fog":(38,0,75,140)},
    66: {"name":"Tuhkan laakso",        "wall":(70,65,65),   "floor":(52,48,48),  "tint":(90,80,80,18),    "fog":(18,16,16,120)},
    67: {"name":"Nefriittiholvi",       "wall":(25,90,55),   "floor":(16,68,38),  "tint":(22,150,60,25),   "fog":(5,36,12,120)},
    68: {"name":"Pimeyden meri",        "wall":(15,25,50),   "floor":(10,18,36),  "tint":(20,40,100,28),   "fog":(4,8,24,135)},
    69: {"name":"Helvetin portti",      "wall":(140,10,10),  "floor":(105,7,7),   "tint":(230,15,15,35),   "fog":(55,4,4,135)},
    70: {"name":"Yhdeksäs torni",       "wall":(140,0,200),  "floor":(100,0,145), "tint":(210,0,255,44),   "fog":(44,0,82,142)},
    71: {"name":"Rubiinisali",          "wall":(160,20,40),  "floor":(125,14,28), "tint":(240,25,50,28),   "fog":(52,6,10,128)},
    72: {"name":"Hämärän kammioit",     "wall":(35,28,55),   "floor":(24,18,40),  "tint":(55,35,110,25),   "fog":(10,7,28,132)},
    73: {"name":"Turkoosit solat",      "wall":(20,100,95),  "floor":(12,75,70),  "tint":(20,160,150,25),  "fog":(5,38,35,122)},
    74: {"name":"Maailmanpuu",          "wall":(35,90,20),   "floor":(24,68,12),  "tint":(30,150,15,25),   "fog":(7,38,4,118)},
    75: {"name":"Kymmenes torni",       "wall":(160,0,210),  "floor":(115,0,152), "tint":(230,0,255,46),   "fog":(48,0,88,145)},
    76: {"name":"Kaaoksen laava",       "wall":(150,50,0),   "floor":(115,36,0),  "tint":(240,90,0,32),    "fog":(55,20,0,130)},
    77: {"name":"Huurteen tunnelit",    "wall":(165,195,215),"floor":(135,162,188),"tint":(110,158,218,22),"fog":(32,48,82,122)},
    78: {"name":"Eebenholvisali",       "wall":(12,10,18),   "floor":(7,6,10),    "tint":(20,10,45,30),    "fog":(3,2,10,138)},
    79: {"name":"Kuolonvirta",          "wall":(110,15,55),  "floor":(82,10,40),  "tint":(180,20,80,35),   "fog":(38,5,18,132)},
    80: {"name":"Yhdestoista torni",    "wall":(170,0,220),  "floor":(122,0,158), "tint":(240,0,255,48),   "fog":(50,0,92,148)},
    81: {"name":"Emerodilaakso",        "wall":(10,110,50),  "floor":(6,82,36),   "tint":(12,180,60,28),   "fog":(3,44,14,122)},
    82: {"name":"Adamanttiholvi",       "wall":(80,80,100),  "floor":(60,60,76),  "tint":(100,100,160,22), "fog":(20,20,42,128)},
    83: {"name":"Infernon sydän",       "wall":(155,20,5),   "floor":(118,14,3),  "tint":(250,35,5,38),    "fog":(58,8,2,135)},
    84: {"name":"Tähtien solat",        "wall":(18,14,50),   "floor":(10,8,35),   "tint":(30,22,110,28),   "fog":(6,5,28,135)},
    85: {"name":"Kahdestoista torni",   "wall":(180,0,230),  "floor":(130,0,166), "tint":(250,0,255,50),   "fog":(52,0,96,150)},
    86: {"name":"Elohopeavirta",        "wall":(150,155,165),"floor":(118,122,132),"tint":(180,185,210,20),"fog":(40,42,58,125)},
    87: {"name":"Kaaoksen kuilu",       "wall":(60,0,80),    "floor":(44,0,58),   "tint":(110,0,155,35),   "fog":(22,0,40,138)},
    88: {"name":"Ikuinen pimeys",       "wall":(8,6,12),     "floor":(4,3,6),     "tint":(15,8,30,35),     "fog":(2,1,5,145)},
    89: {"name":"Tuomion portit",       "wall":(130,5,65),   "floor":(96,3,46),   "tint":(210,8,100,40),   "fog":(44,2,22,138)},
    90: {"name":"Kolmastoista torni",   "wall":(190,0,240),  "floor":(138,0,175), "tint":(255,0,255,52),   "fog":(54,0,100,152)},
    91: {"name":"Lohikäärmeen valtakunta","wall":(125,30,8),"floor":(95,22,5),   "tint":(220,55,0,35),    "fog":(50,12,2,132)},
    92: {"name":"Valkea tyhjyys",       "wall":(220,215,225),"floor":(190,185,198),"tint":(240,235,255,20),"fog":(60,58,70,118)},
    93: {"name":"Verinen synty",        "wall":(140,8,8),    "floor":(105,5,5),   "tint":(230,12,12,40),   "fog":(55,3,3,140)},
    94: {"name":"Kaaoksen aalto",       "wall":(50,0,100),   "floor":(36,0,72),   "tint":(90,0,185,40),    "fog":(18,0,50,142)},
    95: {"name":"Neljästoista torni",   "wall":(200,0,250),  "floor":(145,0,182), "tint":(255,20,255,54),  "fog":(56,4,104,155)},
    96: {"name":"Alkutulen kammioit",   "wall":(160,55,0),   "floor":(122,40,0),  "tint":(255,100,0,40),   "fog":(60,24,0,138)},
    97: {"name":"Synkkä ikuisuus",      "wall":(5,4,8),      "floor":(3,2,5),     "tint":(10,5,22,40),     "fog":(1,0,4,150)},
    98: {"name":"Jumalan portaat",      "wall":(180,150,200),"floor":(148,120,168),"tint":(220,180,255,30),"fog":(50,38,70,138)},
    99: {"name":"Tuomionpäivä",         "wall":(160,0,0),    "floor":(118,0,0),   "tint":(255,0,0,45),     "fog":(62,0,0,148)},
    100:{"name":"Ikuisuuden valtias",   "wall":(120,0,120),  "floor":(86,0,86),   "tint":(200,0,200,55),   "fog":(55,0,55,160)},
}

# ═══════════════════════════════════════════
#  ÄÄNET
# ═══════════════════════════════════════════
def _make_sound(freq=440, dur=0.08, vol=0.18, shape="sq", decay=True):
    sr=22050; n=int(sr*dur); buf=[]
    for i in range(n):
        t=i/sr
        if shape=="sq":   v=1.0 if math.sin(2*math.pi*freq*t)>0 else -1.0
        elif shape=="saw": v=2*(t*freq-math.floor(t*freq+0.5))
        else:              v=math.sin(2*math.pi*freq*t)
        env=(1-i/n) if decay else 1.0
        buf.append(int(v*env*vol*32767))
    return pygame.mixer.Sound(buffer=arr.array("h",buf))

class SoundMgr:
    def __init__(self):
        self.on=True
        try:
            pygame.mixer.init(22050,-16,1,512)
            self.sfx={
                "step":_make_sound(180,.04,.06,"sq"),
                "hit":_make_sound(120,.10,.20,"sq"),
                "player_hit":_make_sound(80,.12,.22,"sq"),
                "die":_make_sound(60,.25,.20,"saw"),
                "pickup":_make_sound(660,.08,.15,"sin"),
                "levelup":_make_sound(880,.20,.18,"sin",False),
                "gold":_make_sound(520,.07,.14,"sin"),
                "shop":_make_sound(440,.12,.14,"sin"),
                "error":_make_sound(100,.08,.15,"sq"),
                "stairs":_make_sound(330,.15,.16,"sin"),
                "boss":_make_sound(55,.40,.25,"saw"),
                "menu_sel":_make_sound(550,.05,.10,"sin"),
            }
        except: self.sfx={}; self.on=False
    def play(self,n):
        if self.on and n in self.sfx:
            try: self.sfx[n].play()
            except: pass

SFX=SoundMgr()

# ═══════════════════════════════════════════
#  VFX
# ═══════════════════════════════════════════
class VFX:
    def __init__(self,wx,wy,text,color,life=55,big=False):
        self.wx=wx*TILE+TILE//2; self.wy=wy*TILE
        self.text=text; self.color=color; self.life=life
        self.age=0; self.vy=-0.9; self.big=big
    def update(self):
        self.age+=1; self.wy+=self.vy; self.vy*=0.92
        return self.age<self.life
    def draw(self,screen,fonts,cx,cy):
        a=max(0,255-int(255*self.age/self.life))
        sx=self.wx-cx*TILE; sy=self.wy-cy*TILE
        if not(-30<sx<SCREEN_W and -20<sy<SCREEN_H): return
        f=fonts["vfx_big"] if self.big else fonts["vfx"]
        s=f.render(self.text,True,self.color); s.set_alpha(a)
        screen.blit(s,(sx-s.get_width()//2,sy))

# ═══════════════════════════════════════════
#  KARTAN GENEROINTI
# ═══════════════════════════════════════════
class Room:
    def __init__(self,x,y,w,h): self.x,self.y,self.w,self.h=x,y,w,h
    def center(self): return(self.x+self.w//2,self.y+self.h//2)
    def random_floor(self):
        return(random.randint(self.x+1,self.x+self.w-2),
               random.randint(self.y+1,self.y+self.h-2))

class BSPNode:
    def __init__(self,x,y,w,h):
        self.x,self.y,self.w,self.h=x,y,w,h; self.left=self.right=self.room=None
    def split(self,mn=10):
        if self.left: return False
        hz=random.random()>.5
        if self.w>self.h and self.w/self.h>=1.25: hz=False
        elif self.h>self.w and self.h/self.w>=1.25: hz=True
        mx=(self.h if hz else self.w)-mn
        if mx<=mn: return False
        sp=random.randint(mn,mx)
        if hz:
            self.left=BSPNode(self.x,self.y,self.w,sp)
            self.right=BSPNode(self.x,self.y+sp,self.w,self.h-sp)
        else:
            self.left=BSPNode(self.x,self.y,sp,self.h)
            self.right=BSPNode(self.x+sp,self.y,self.w-sp,self.h)
        return True
    def leaves(self):
        if not self.left: return[self]
        return self.left.leaves()+self.right.leaves()

def generate_level(floor_num,has_shop=True,is_boss_floor=False):
    tiles=[[WALL]*MAP_W for _ in range(MAP_H)]
    explored=[[False]*MAP_W for _ in range(MAP_H)]
    root=BSPNode(1,1,MAP_W-2,MAP_H-2); nodes=[root]
    for _ in range(5+min(floor_num,3)):
        nxt=[]
        for n in nodes:
            if n.split(): nxt+=[n.left,n.right]
            else: nxt.append(n)
        nodes=nxt
    rooms=[]
    for lf in root.leaves():
        m=2; rw=random.randint(5,max(5,lf.w-m*2)); rh=random.randint(5,max(5,lf.h-m*2))
        rx=lf.x+random.randint(m,max(m,lf.w-rw-m)); ry=lf.y+random.randint(m,max(m,lf.h-rh-m))
        r=Room(rx,ry,rw,rh); rooms.append(r); lf.room=r
        for dy in range(rh):
            for dx in range(rw): tiles[ry+dy][rx+dx]=FLOOR
    random.shuffle(rooms)
    for i in range(len(rooms)-1):
        cx1,cy1=rooms[i].center(); cx2,cy2=rooms[i+1].center()
        if random.random()<.5:
            for x in range(min(cx1,cx2),max(cx1,cx2)+1): tiles[cy1][x]=FLOOR
            for y in range(min(cy1,cy2),max(cy1,cy2)+1): tiles[y][cx2]=FLOOR
        else:
            for y in range(min(cy1,cy2),max(cy1,cy2)+1): tiles[y][cx1]=FLOOR
            for x in range(min(cx1,cx2),max(cx1,cx2)+1): tiles[cy2][x]=FLOOR
    # Portaat: bossitasoilla toiseksi viimeiseen huoneeseen, muuten viimeiseen
    stair_room = rooms[-2] if is_boss_floor and len(rooms)>=3 else rooms[-1]
    lc,lr=stair_room.center(); tiles[lr][lc]=STAIRS
    shop_room=None
    if has_shop and len(rooms)>3:
        shop_room=rooms[len(rooms)//2]; sc,sr=shop_room.center(); tiles[sr][sc]=SHOP_TILE
    return tiles,explored,rooms,shop_room

def compute_fov(tiles,px,py,radius=11):
    vis=[[False]*MAP_W for _ in range(MAP_H)]; vis[py][px]=True
    for deg in range(360):
        rad=math.radians(deg); dx,dy=math.cos(rad),math.sin(rad)
        ox,oy=px+.5,py+.5
        for _ in range(radius):
            ix,iy=int(ox),int(oy)
            if 0<=ix<MAP_W and 0<=iy<MAP_H:
                vis[iy][ix]=True
                if tiles[iy][ix]==WALL: break
            ox+=dx; oy+=dy
    return vis

# ═══════════════════════════════════════════
#  ESINEET
# ═══════════════════════════════════════════
ITEM_DEF={
    "health":  ("Terveysjuoma",  "+12 HP",           P["red"],    "!", True),
    "big_hp":  ("Eliksiiri",     "Täysi parannus",    (240,80,80),"!", True),
    "gold":    ("Kultakolikot",  "+15 kultaa",        P["gold"],  "$", False),
    "sword":   ("Miekka",        "+2 ATK pysyvästi",  P["orange"],"/", False),
    "shield":  ("Kilpi",         "+1 DEF pysyvästi",  P["blue"],  "]", False),
    "xp":      ("Kokemuskivi",   "+15 XP",            P["purple"],"*", True),
    "bomb":    ("Pommi",         "5 dmg kaikille FOV",P["orange"],"o", True),
    "antidote":("Vastalääke",    "Poistaa myrkyn",    P["cyan"],  "~", True),
}

SHOP_ITEMS=[("health",15),("big_hp",35),("bomb",25),("sword",40),("shield",40),("xp",20)]

class ItemObj:
    def __init__(self,x,y,itype):
        self.x,self.y=x,y; self.itype=itype
        self.bob_t=random.uniform(0,math.pi*2)
        info=ITEM_DEF[itype]
        self.name,self.desc,self.color,self.char,self.usable=info

# ═══════════════════════════════════════════
#  ENTITEETIT
# ═══════════════════════════════════════════
class Entity:
    def __init__(self,x,y,name,hp,atk,dfn):
        self.x=x; self.y=y; self.name=name
        self.hp=self.max_hp=hp; self.attack=atk; self.defense=dfn
        self.alive=True; self.anim_t=random.uniform(0,math.pi*2); self.flash=0
    def take_damage(self,dmg):
        d=max(1,dmg-self.defense); self.hp=max(0,self.hp-d)
        if self.hp==0: self.alive=False
        self.flash=10; return d
    def update(self):
        if self.flash>0: self.flash-=1
        self.anim_t+=0.04

CLASS_DEF={
    "Soturi":{"icon":"S","color":P["orange"],"hp":45,"atk":7,"dfn":3,
              "desc":"Kestävä taistelija. Paljon HP ja puolustus."},
    "Magi":  {"icon":"M","color":P["purple"],"hp":28,"atk":10,"dfn":1,
              "desc":"Voimakas hyökkääjä. Heikko mutta tappava."},
    "Varas": {"icon":"V","color":P["cyan"],  "hp":32,"atk":8, "dfn":2,
              "desc":"Nopea. 25% kriittinen isku (x2 vahinko)."},
}

class Player(Entity):
    def __init__(self,x,y,cls="Soturi"):
        cd=CLASS_DEF[cls]
        super().__init__(x,y,cls,cd["hp"],cd["atk"],cd["dfn"])
        self.cls=cls; self.gold=10; self.level=1; self.xp=0; self.xp_next=20
        self.inventory=[]; self.messages=[]; self.kills=0
        self.items_collected=0; self.poisoned=0; self.score=0
    def msg(self,text,color=None):
        self.messages.append((text,color or P["text"]))
        if len(self.messages)>10: self.messages.pop(0)
    def gain_xp(self,amt):
        self.xp+=amt
        while self.xp>=self.xp_next:
            self.xp-=self.xp_next; self.level+=1; self.xp_next=int(self.xp_next*1.6)
            self.max_hp+=6; self.hp=min(self.hp+10,self.max_hp); self.attack+=1
            SFX.play("levelup"); self.msg(f"TASON NOUSU! Taso {self.level}!",P["gold"])
    def add_item(self,itype):
        if len(self.inventory)>=8: return False
        self.inventory.append(itype); return True
    def use_item(self,idx,enemies,fov):
        if idx<0 or idx>=len(self.inventory): return False
        itype=self.inventory[idx]; info=ITEM_DEF[itype]
        if not info[4]: return False
        used=True
        if itype=="health":
            h=random.randint(10,15); self.hp=min(self.hp+h,self.max_hp)
            self.msg(f"Joit juoman: +{h} HP",P["red"]); SFX.play("pickup")
        elif itype=="big_hp":
            self.hp=self.max_hp; self.msg("Eliksiiri: täysi parannus!",(240,100,100)); SFX.play("pickup")
        elif itype=="xp":
            g=random.randint(12,22); self.gain_xp(g)
            self.msg(f"Kokemuskivi: +{g} XP",P["purple"])
        elif itype=="bomb":
            killed=0
            for e in enemies:
                if e.alive and fov[e.y][e.x]:
                    e.take_damage(5+self.attack//2)
                    if not e.alive: killed+=1
            self.msg(f"Pommi! ({killed} kaatui)",P["orange"]); SFX.play("hit")
        elif itype=="antidote":
            self.poisoned=0; self.msg("Myrkky neutraloitu!",P["cyan"])
        else: used=False
        if used: self.inventory.pop(idx)
        return used

ENEMY_DEF={
    "goblin":      ("Gobliini",    8, 3,0,  5,False),
    "skeleton":    ("Luuranko",   12, 4,1,  8,False),
    "orc":         ("Örkkiä",     18, 6,2, 12,False),
    "troll":       ("Peikko",     30, 9,3, 22,False),
    "wizard":      ("Velho",      14,10,0, 18,True),
    "spider":      ("Hämähäkki",  10, 4,0,  7,False),
    "vampire":     ("Vampyyri",   22, 8,1, 20,False),
    "demon":       ("Demoni",     28,11,2, 28,False),
    "golem":       ("Kivijätti",  40,10,5, 35,False),
    "necromancer": ("Kuolonmagi", 18,12,0, 30,True),
    "wraith":      ("Haamu",      16, 9,2, 25,False),
}

class Enemy(Entity):
    def __init__(self,x,y,etype,floor_num):
        nm,hp,atk,dfn,xp,ranged=ENEMY_DEF[etype]
        bonus=floor_num//2
        super().__init__(x,y,nm,hp+bonus*3,atk+bonus,dfn)
        self.max_hp=hp+bonus*3; self.xp_reward=xp+bonus*2
        self.etype=etype; self.ranged=ranged; self.saw_player=False

# ═══════════════════════════════════════════
#  LOPPUBOSSI
# ═══════════════════════════════════════════
class Boss(Entity):
    # floor -> [(nimi, hp, atk, dfn, col), ...]
    BOSS_DATA = {
        5:  [("Varjolord",              120,14,4,(200,30,30)),
             ("Varjolord II",            80,18,2,(240,60,210))],
        10: [("Abyssin kuningas",       200,20,6,(160,0,200)),
             ("Abyssin kuningas II",    130,25,4,(220,0,255)),
             ("Abyssin kuningas III",    80,30,2,(255,80,255))],
        15: [("Lohikäärme Ignaras",     280,22,7,(200,80,0)),
             ("Ignaras Raivo",          180,28,5,(255,140,0)),
             ("Ignaras Tuhkana",        110,35,3,(255,60,0))],
        20: [("Kuolemanenkeli",         360,26,8,(180,180,220)),
             ("Tuomion enkeli",         230,32,6,(220,200,255)),
             ("Tuhon enkeli",           150,38,4,(255,240,255))],
        25: [("Kaaos Titaani",          460,30,10,(130,0,200)),
             ("Kaaos Titaani II",       300,36,8,(180,0,255)),
             ("Kaaos Titaani III",      200,42,6,(220,80,255))],
        30: [("Ikuisuuden Jumala",      580,36,12,(255,0,200)),
             ("Ikuisuuden Jumala II",   380,42,10,(255,80,230)),
             ("Jumalan Loppumuoto",     240,48,8,(255,200,255))],
        35: [("Tulikraateri",           720,40,13,(220,100,0)),
             ("Tulikraateri Raivo",     480,46,11,(255,140,30)),
             ("Tulikraateri Inferno",   300,52,9,(255,80,0))],
        40: [("Titaanin Vartija",       900,44,15,(120,120,140)),
             ("Titaanin Vartija II",    600,50,13,(160,160,190)),
             ("Titaanin Vartija III",   380,56,11,(200,200,230))],
        45: [("Varjon Hallitsija",      1100,48,16,(50,0,110)),
             ("Varjon Hallitsija II",    720,54,14,(90,0,180)),
             ("Varjon Hallitsija III",   440,60,12,(140,0,240))],
        50: [("Demonikuningas",         1350,52,18,(200,0,50)),
             ("Demonikuningas II",       900,58,16,(240,20,80)),
             ("Demonikuningas III",      550,65,14,(255,60,110))],
        55: [("Jäinen Kauhujumala",     1650,56,19,(100,180,240)),
             ("Jäinen Kauhujumala II",  1100,62,17,(150,220,255)),
             ("Jäinen Kauhujumala III",  680,70,15,(200,240,255))],
        60: [("Tulivuoren Henki",       2000,60,21,(255,80,0)),
             ("Tulivuoren Henki II",    1350,66,19,(255,120,40)),
             ("Tulivuoren Henki III",    820,74,17,(255,160,80))],
        65: [("Kaaoksen Isä",           2450,65,23,(100,0,200)),
             ("Kaaoksen Isä II",        1650,72,21,(150,20,255)),
             ("Kaaoksen Isä III",       1000,80,19,(200,80,255))],
        70: [("Yö Ikuinen",             3000,70,25,(20,0,60)),
             ("Yö Ikuinen II",          2000,78,23,(40,0,110)),
             ("Yö Ikuinen III",         1200,86,21,(80,20,180))],
        75: [("Tuhon Arkkienkeli",      3650,75,27,(200,200,255)),
             ("Tuhon Arkkienkeli II",   2450,84,25,(220,210,255)),
             ("Tuhon Arkkienkeli III",  1500,93,23,(255,240,255))],
        80: [("Universaalin Pimeys",    4400,80,29,(5,0,15)),
             ("Universaalin Pimeys II", 2950,90,27,(15,0,40)),
             ("Universaalin Pimeys III",1800,100,25,(40,10,90))],
        85: [("Kaaoksen Jumala",        5300,86,32,(180,0,255)),
             ("Kaaoksen Jumala II",     3550,96,30,(210,40,255)),
             ("Kaaoksen Jumala III",    2200,107,28,(240,100,255))],
        90: [("Tuomion Jumala",         6400,92,35,(200,0,0)),
             ("Tuomion Jumala II",      4300,103,33,(240,30,30)),
             ("Tuomion Jumala III",     2650,115,31,(255,80,80))],
        95: [("Kaiken Loppu",           7700,99,38,(80,0,80)),
             ("Kaiken Loppu II",        5200,111,36,(130,0,130)),
             ("Kaiken Loppu III",       3200,124,34,(200,0,200))],
        100:[("IKUISUUDEN HERRA",       9999,110,42,(255,0,255)),
             ("IKUISUUDEN HERRA II",    6666,124,40,(255,80,255)),
             ("IKUISUUDEN HERRA – LOPPU",4000,140,38,(255,200,255))],
    }
    def __init__(self,x,y,floor_num=5):
        self.floor_num=floor_num
        phases=self.BOSS_DATA.get(floor_num, self.BOSS_DATA[5])
        self.phases=phases; ph=phases[0]
        super().__init__(x,y,ph[0],ph[1],ph[2],ph[3])
        self.max_hp=ph[1]; self.phase=0
        self.xp_reward=100 + floor_num*30
        self.etype="boss"; self.ranged=False; self.saw_player=True
        self.col=ph[4]; self.rage_timer=0
    def tick_rage(self):
        self.rage_timer+=1
        rage_cap=self.phases[0][2]+20  # max ATK = alkuperäinen + 20
        if self.rage_timer%8==0 and self.hp<self.max_hp*0.4:
            self.attack=min(self.attack+1,rage_cap)
    def check_phase(self):
        next_phase=self.phase+1
        if not self.alive and next_phase < len(self.phases):
            self.phase=next_phase; ph=self.phases[next_phase]
            self.hp=ph[1]; self.max_hp=ph[1]
            self.attack=ph[2]; self.defense=ph[3]
            self.name=ph[0]; self.col=ph[4]
            self.alive=True
            return True
        return False

# ═══════════════════════════════════════════
#  HIGHSCORE (muistissa – toimii selaimessa)
# ═══════════════════════════════════════════
_SCORES_MEMORY = []

def load_scores():
    return list(_SCORES_MEMORY)

def save_score(name,score,cls,floor,kills):
    global _SCORES_MEMORY
    _SCORES_MEMORY.append({"name":name,"score":score,"cls":cls,"floor":floor,"kills":kills})
    _SCORES_MEMORY.sort(key=lambda x:x["score"],reverse=True)
    _SCORES_MEMORY=_SCORES_MEMORY[:10]
    return _SCORES_MEMORY

def calc_score(p,floor):
    return p.kills*100 + p.gold*10 + p.level*50 + floor*200

# ═══════════════════════════════════════════
#  APURIT
# ═══════════════════════════════════════════
def _wrap(text,width):
    words=text.split(); lines=[]; line=""
    for w in words:
        if len(line)+len(w)+1<=width: line+=(" " if line else "")+w
        else: lines.append(line); line=w
    if line: lines.append(line)
    return lines

def mouse_in(rect,mx,my):
    x,y,w,h=rect
    return x<=mx<x+w and y<=my<y+h

# ═══════════════════════════════════════════
#  PÄÄVALIKKO
# ═══════════════════════════════════════════
def main_menu(screen,fonts,mx,my):
    btn_w,btn_h=280,52; btn_x=SCREEN_W//2-btn_w//2
    buttons=[("UUSI PELI","newgame"),("TULOSTAULUKKO","scores"),("OHJE","help"),("LOPETA","quit")]
    screen.fill(P["bg"])
    t_offset=pygame.time.get_ticks()/1000
    for i in range(18):
        a=t_offset+i*0.7; r=80+30*math.sin(a*0.5)
        cx2=SCREEN_W//2+int(math.cos(a)*r*3); cy2=SCREEN_H//2+int(math.sin(a)*r*1.5)
        pygame.draw.circle(screen,(20,15,35),(cx2,cy2),3+i%3)
    title=fonts["title"].render("Sokkelo Peli",True,P["gold"])
    sub=fonts["med"].render("v 1",True,P["dim"])
    screen.blit(title,(SCREEN_W//2-title.get_width()//2,120))
    screen.blit(sub,(SCREEN_W//2-sub.get_width()//2,168))
    pygame.draw.line(screen,P["border"],(SCREEN_W//2-200,192),(SCREEN_W//2+200,192),1)
    rects=[]
    for i,(label,action) in enumerate(buttons):
        by=280+i*(btn_h+14); rect=(btn_x,by,btn_w,btn_h)
        hov=mouse_in(rect,mx,my)
        pygame.draw.rect(screen,P["panel2"] if hov else P["panel"],rect,border_radius=8)
        pygame.draw.rect(screen,P["gold"] if hov else P["border"],rect,2,border_radius=8)
        t=fonts["med"].render(label,True,P["white"] if hov else P["text"])
        screen.blit(t,(SCREEN_W//2-t.get_width()//2,by+btn_h//2-t.get_height()//2))
        rects.append((rect,action))
    hint=fonts["tiny"].render("Klikkaa tai paina ENTER aloittaaksesi",True,P["dim"])
    screen.blit(hint,(SCREEN_W//2-hint.get_width()//2,SCREEN_H-40))
    return rects

def scores_screen(screen,fonts):
    screen.fill(P["bg"])
    t=fonts["title"].render("TULOSTAULUKKO",True,P["gold"])
    screen.blit(t,(SCREEN_W//2-t.get_width()//2,60))
    pygame.draw.line(screen,P["border"],(SCREEN_W//2-250,104),(SCREEN_W//2+250,104),1)
    scores=load_scores()
    if not scores:
        nt=fonts["med"].render("Ei vielä tuloksia!",True,P["dim"])
        screen.blit(nt,(SCREEN_W//2-nt.get_width()//2,SCREEN_H//2))
    else:
        headers=["#","Nimi","Pisteet","Luokka","Kerros","Tapot"]
        col_x=[SCREEN_W//2-310,SCREEN_W//2-230,SCREEN_W//2-80,SCREEN_W//2+30,SCREEN_W//2+130,SCREEN_W//2+220]
        for hi,h in enumerate(headers):
            ht=fonts["small"].render(h,True,P["dim"]); screen.blit(ht,(col_x[hi],118))
        pygame.draw.line(screen,P["border"],(SCREEN_W//2-310,136),(SCREEN_W//2+300,136),1)
        for ri,sc in enumerate(scores):
            ry=148+ri*36
            row_col=P["gold"] if ri==0 else(P["text"] if ri<3 else P["dim"])
            cols=[str(ri+1),sc.get("name","?"),str(sc.get("score",0)),sc.get("cls","?"),str(sc.get("floor",0)),str(sc.get("kills",0))]
            for ci,cv in enumerate(cols):
                ct=fonts["small"].render(cv,True,row_col); screen.blit(ct,(col_x[ci],ry))
    back=fonts["med"].render("ESC / klikkaa palataksesi",True,P["dim"])
    screen.blit(back,(SCREEN_W//2-back.get_width()//2,SCREEN_H-50))

HELP_PAGES=[
    ("PERUSTEET",[
        ("Tavoite:",P["gold"]),
        ("Selviä kaikki 100 kerrosta ja voita loppubossi.",P["text"]),
        ("",P["text"]),
        ("Liikkuminen:",P["gold"]),
        ("WASD tai nuolinäppäimet = liiku / hyökkää.",P["text"]),
        ("Kävellessä vihollisen päälle = hyökkäät sitä.",P["text"]),
        ("",P["text"]),
        ("Portaat:",P["gold"]),
        ("Asetu portaille (> merkki) siirtyäksesi seuraavaan kerrokseen.",P["text"]),
        ("",P["text"]),
        ("Näkökenttä (FOV):",P["gold"]),
        ("Näet vain valaistulle alueelle. Tutkitut alueet himmeämpinä.",P["text"]),
    ]),
    ("TAISTELUT",[
        ("Hyökkäys:",P["gold"]),
        ("Kävele vihollisen päälle. Vahinko = ATK - DEF (min 1).",P["text"]),
        ("",P["text"]),
        ("Luokkabonukset:",P["gold"]),
        ("Varas: 25 % kriittinen isku (x2 vahinko).",P["cyan"]),
        ("Magi: Korkein hyökkäys, matala puolustus.",P["purple"]),
        ("Soturi: Korkea HP ja puolustus.",P["orange"]),
        ("",P["text"]),
        ("Bossikerrokset:",P["gold"]),
        ("Joka 5. kerros sisältää useampivaiheiset bossit.",P["text"]),
        ("Bossit voimistuvat HP:n laskiessa.",P["red"]),
    ]),
    ("INVENTAARIO",[
        ("Inventaario:",P["gold"]),
        ("E = avaa/sulje. Max 8 esinettä.",P["text"]),
        ("Klikkaa tai paina 1-8 käyttääksesi.",P["text"]),
        ("",P["text"]),
        ("Esineet:",P["gold"]),
        ("! Terveysjuoma  = +10-15 HP",P["red"]),
        ("! Eliksiiri     = Täysi parannus",P["red"]),
        ("o Pommi         = 5+ dmg kaikille FOV:ssa",P["orange"]),
        ("~ Vastalääke    = Poistaa myrkyn",P["cyan"]),
        ("* Kokemuskivi   = +12-22 XP",P["purple"]),
        ("/ Miekka        = +2 ATK pysyvästi",P["orange"]),
        ("] Kilpi         = +1 DEF pysyvästi",P["blue"]),
        ("$ Kulta         = +15 kultaa",P["gold"]),
    ]),
    ("KAUPPA & MUUT",[
        ("Kauppa:",P["gold"]),
        ("Joillakin kerroksilla on kauppias.",P["text"]),
        ("Astu kauppiaan päälle avataksesi kaupan.",P["text"]),
        ("",P["text"]),
        ("HP-kasvu:",P["gold"]),
        ("Max HP kasvaa +20% joka kerroksen jälkeen.",P["green"]),
        ("",P["text"]),
        ("Myrkky:",P["gold"]),
        ("Jotkut viholliset myrkyttävät. Vahinkoa joka vuoro.",P["text"]),
        ("",P["text"]),
        ("Pisteet:",P["gold"]),
        ("Tapat*100 + Kulta*10 + Taso*50 + Kerros*200.",P["text"]),
    ]),
]

def help_screen(screen,fonts,page,mx,my):
    screen.fill(P["bg"])
    t_offset=pygame.time.get_ticks()/1000
    for i in range(18):
        a=t_offset+i*0.7; r=80+30*math.sin(a*0.5)
        cx2=SCREEN_W//2+int(math.cos(a)*r*3); cy2=SCREEN_H//2+int(math.sin(a)*r*1.5)
        pygame.draw.circle(screen,(20,15,35),(cx2,cy2),3+i%3)
    title_s=fonts["title"].render("OHJE",True,P["gold"])
    screen.blit(title_s,(SCREEN_W//2-title_s.get_width()//2,55))
    pygame.draw.line(screen,P["border"],(SCREEN_W//2-250,100),(SCREEN_W//2+250,100),1)
    tab_w=190; tab_gap=12; total_tw=len(HELP_PAGES)*tab_w+(len(HELP_PAGES)-1)*tab_gap
    tab_x0=SCREEN_W//2-total_tw//2; tab_rects=[]
    for i,(ptitle,_) in enumerate(HELP_PAGES):
        tx=tab_x0+i*(tab_w+tab_gap); trect=(tx,112,tab_w,32); tab_rects.append(trect)
        hov=mouse_in(trect,mx,my); sel=(i==page)
        pygame.draw.rect(screen,P["panel2"] if(sel or hov) else P["panel"],trect,border_radius=6)
        pygame.draw.rect(screen,P["gold"] if sel else(P["border"] if not hov else P["dim"]),trect,2 if sel else 1,border_radius=6)
        ts=fonts["small"].render(ptitle,True,P["white"] if sel else P["text"])
        screen.blit(ts,(tx+tab_w//2-ts.get_width()//2,118))
    box_x=SCREEN_W//2-420; box_y=158; box_w=840; box_h=520
    surf=pygame.Surface((box_w,box_h),pygame.SRCALPHA); surf.fill((16,13,26,230))
    screen.blit(surf,(box_x,box_y))
    pygame.draw.rect(screen,P["border"],(box_x,box_y,box_w,box_h),1,border_radius=8)
    _,lines=HELP_PAGES[page]; cy=box_y+22
    for text,col in lines:
        if text=="": cy+=8; continue
        ts=fonts["small"].render(text,True,col); screen.blit(ts,(box_x+28,cy)); cy+=24
    btn_w2,btn_h2=140,44
    prev_rect=(box_x,box_y+box_h+18,btn_w2,btn_h2)
    next_rect=(box_x+box_w-btn_w2,box_y+box_h+18,btn_w2,btn_h2)
    back_rect=(SCREEN_W//2-70,box_y+box_h+18,140,btn_h2)
    for rect,label,active in[(prev_rect,"< EDELLINEN",page>0),(back_rect,"TAKAISIN",True),(next_rect,"SEURAAVA >",page<len(HELP_PAGES)-1)]:
        hov=mouse_in(rect,mx,my) and active
        pygame.draw.rect(screen,P["panel2"] if hov else(P["panel"] if active else(8,6,14)),rect,border_radius=8)
        pygame.draw.rect(screen,P["gold"] if hov else(P["border"] if active else(30,25,45)),rect,2,border_radius=8)
        ts2=fonts["small"].render(label,True,P["white"] if active else P["dim"])
        screen.blit(ts2,(rect[0]+rect[2]//2-ts2.get_width()//2,rect[1]+rect[3]//2-ts2.get_height()//2))
    pn=fonts["tiny"].render(f"Sivu {page+1}/{len(HELP_PAGES)}",True,P["dim"])
    screen.blit(pn,(SCREEN_W//2-pn.get_width()//2,box_y+box_h+30))
    return prev_rect,next_rect,back_rect,tab_rects

def name_entry_screen(screen,fonts,score,cls,floor,kills,name=""):
    screen.fill(P["bg"])
    t1=fonts["title"].render("PELI OHI",True,P["gold"])
    t2=fonts["med"].render(f"Pisteesi: {score}",True,P["white"])
    screen.blit(t1,(SCREEN_W//2-t1.get_width()//2,120))
    screen.blit(t2,(SCREEN_W//2-t2.get_width()//2,175))
    pt=fonts["med"].render("Syötä nimesi:",True,P["text"])
    screen.blit(pt,(SCREEN_W//2-pt.get_width()//2,240))
    box_rect=(SCREEN_W//2-150,280,300,44)
    pygame.draw.rect(screen,P["panel2"],box_rect,border_radius=6)
    pygame.draw.rect(screen,P["gold"],box_rect,2,border_radius=6)
    nt=fonts["med"].render(name+"_",True,P["white"])
    screen.blit(nt,(SCREEN_W//2-nt.get_width()//2,290))
    hint=fonts["tiny"].render("ENTER vahvistaa",True,P["dim"])
    screen.blit(hint,(SCREEN_W//2-hint.get_width()//2,340))

def class_select_screen(screen,fonts,sel,mx,my):
    keys=list(CLASS_DEF.keys())
    bw,bh=280,210; total_w=len(keys)*bw+(len(keys)-1)*24
    start_x=SCREEN_W//2-total_w//2; by0=SCREEN_H//2-bh//2
    screen.fill(P["bg"])
    t=fonts["title"].render("VALITSE LUOKKA",True,P["gold"])
    screen.blit(t,(SCREEN_W//2-t.get_width()//2,80))
    sub=fonts["med"].render("Klikkaa tai nuolinäppäimet + ENTER",True,P["dim"])
    screen.blit(sub,(SCREEN_W//2-sub.get_width()//2,130))
    card_rects=[]
    for i,cls in enumerate(keys):
        cd=CLASS_DEF[cls]; bx=start_x+i*(bw+24); rect=(bx,by0,bw,bh); card_rects.append(rect)
        hov=mouse_in(rect,mx,my); selected=(i==sel) or hov
        pygame.draw.rect(screen,P["panel2"] if selected else P["panel"],rect,border_radius=10)
        pygame.draw.rect(screen,cd["color"] if selected else P["border"],rect,3 if selected else 1,border_radius=10)
        it=fonts["big"].render(cd["icon"],True,cd["color"])
        screen.blit(it,(bx+bw//2-it.get_width()//2,by0+18))
        nt=fonts["med"].render(cls,True,P["white"] if selected else P["text"])
        screen.blit(nt,(bx+bw//2-nt.get_width()//2,by0+65))
        for j,(st,sc) in enumerate([(f"HP  {cd['hp']}",P["hp_hi"]),(f"ATK {cd['atk']}",P["orange"]),(f"DEF {cd['dfn']}",P["blue"])]):
            s=fonts["small"].render(st,True,sc); screen.blit(s,(bx+20,by0+100+j*22))
        for j,dl in enumerate(_wrap(cd["desc"],26)):
            d=fonts["tiny"].render(dl,True,P["dim"]); screen.blit(d,(bx+10,by0+bh-52+j*14))
    return card_rects,keys


# ═══════════════════════════════════════════
#  INVENTAARIO UI  (hiiri + näppäimet)
# ═══════════════════════════════════════════
class InventoryUI:
    def __init__(self): self.open=False; self.hovered=-1
    def toggle(self): self.open=not self.open; self.hovered=-1

    def get_slot_rects(self):
        W,H=520,440; x0=SCREEN_W//2-W//2; y0=SCREEN_H//2-H//2
        sw,sh=60,60; gap=12; row_x=x0+(W-(4*(sw+gap)-gap))//2
        rects=[]
        for i in range(8):
            col=i%4; row=i//4
            sx=row_x+col*(sw+gap); sy=y0+55+row*(sh+gap+22)
            rects.append((sx,sy,sw,sh))
        return x0,y0,W,H,rects

    def handle_mouse(self,mx,my,player,enemies,fov):
        if not self.open: return
        x0,y0,W,H,rects=self.get_slot_rects()
        self.hovered=-1
        for i,r in enumerate(rects):
            if mouse_in(r,mx,my): self.hovered=i
        # Klikkaus käyttää esineen
        pass

    def handle_click(self,mx,my,player,enemies,fov):
        if not self.open: return False
        x0,y0,W,H,rects=self.get_slot_rects()
        # Sulje-nappi
        close_rect=(x0+W-32,y0+6,28,28)
        if mouse_in(close_rect,mx,my): self.open=False; return True
        for i,r in enumerate(rects):
            if mouse_in(r,mx,my) and i<len(player.inventory):
                ok=player.use_item(i,enemies,fov)
                if not ok: player.msg("Ei voi käyttää!",P["dim"])
                return True
        return False

    def draw(self,screen,player,fonts,sprites):
        if not self.open: return
        x0,y0,W,H,rects=self.get_slot_rects()
        surf=pygame.Surface((W,H),pygame.SRCALPHA); surf.fill((16,13,26,235))
        screen.blit(surf,(x0,y0))
        pygame.draw.rect(screen,P["border"],(x0,y0,W,H),2,border_radius=8)
        t=fonts["med"].render("INVENTAARIO",True,P["gold"])
        screen.blit(t,(x0+W//2-t.get_width()//2,y0+12))
        # Sulje-nappi X
        close_r=(x0+W-32,y0+6,28,28)
        mx,my=pygame.mouse.get_pos()
        hov_close=mouse_in(close_r,mx,my)
        pygame.draw.rect(screen,P["red"] if hov_close else P["panel2"],close_r,border_radius=5)
        xt=fonts["small"].render("X",True,P["white"])
        screen.blit(xt,(close_r[0]+close_r[2]//2-xt.get_width()//2,close_r[1]+5))
        pygame.draw.line(screen,P["border"],(x0+10,y0+42),(x0+W-10,y0+42),1)

        tooltip_item=None
        for i,r in enumerate(rects):
            sx,sy,sw,sh=r
            has=i<len(player.inventory)
            hov=(i==self.hovered)
            bg=P["panel2"] if hov and has else(P["panel2"] if has else P["panel"])
            border=P["gold"] if hov and has else P["border"]
            pygame.draw.rect(screen,bg,(sx,sy,sw,sh),border_radius=7)
            pygame.draw.rect(screen,border,(sx,sy,sw,sh),2 if hov else 1,border_radius=7)
            num=fonts["tiny"].render(str(i+1),True,P["dim"])
            screen.blit(num,(sx+3,sy+3))
            if has:
                itype=player.inventory[i]; info=ITEM_DEF[itype]
                skey=itype if itype!="big_hp" else "health"
                if sprites.get(skey):
                    img=pygame.transform.scale(sprites[skey],(38,38))
                    screen.blit(img,(sx+11,sy+10))
                else:
                    ct=fonts["big"].render(info[3],True,info[2])
                    screen.blit(ct,(sx+sw//2-ct.get_width()//2,sy+14))
                nt=fonts["tiny"].render(info[0][:9],True,P["text"])
                screen.blit(nt,(sx+sw//2-nt.get_width()//2,sy+sh+3))
                if hov: tooltip_item=itype

        # Tooltip
        if tooltip_item:
            info=ITEM_DEF[tooltip_item]
            tbox=fonts["small"].render(f"{info[0]} — {info[1]}",True,info[2])
            screen.blit(tbox,(x0+W//2-tbox.get_width()//2,y0+H-48))

        hint=fonts["tiny"].render("Klikkaa käyttääksesi  |  1-8: käytä  |  E/X: sulje",True,P["dim"])
        screen.blit(hint,(x0+W//2-hint.get_width()//2,y0+H-24))

# ═══════════════════════════════════════════
#  KAUPPIAS UI  (hiiri + näppäimet)
# ═══════════════════════════════════════════
class ShopUI:
    def __init__(self): self.open=False; self.cursor=0; self.hovered=-1

    def get_item_rects(self):
        W,H=480,430; x0=SCREEN_W//2-W//2; y0=SCREEN_H//2-H//2
        rects=[]
        for i in range(len(SHOP_ITEMS)):
            iy=y0+52+i*56
            rects.append((x0+8,iy,W-16,50))
        return x0,y0,W,H,rects

    def handle_mouse(self,mx,my):
        if not self.open: return
        x0,y0,W,H,rects=self.get_item_rects()
        self.hovered=-1
        for i,r in enumerate(rects):
            if mouse_in(r,mx,my): self.hovered=i; self.cursor=i

    def handle_click(self,mx,my,player):
        if not self.open: return False
        x0,y0,W,H,rects=self.get_item_rects()
        # Sulje
        close_r=(x0+W-32,y0+6,28,28)
        if mouse_in(close_r,mx,my): self.open=False; return True
        for i,r in enumerate(rects):
            if mouse_in(r,mx,my):
                self.cursor=i; self._do_buy(player); return True
        return False

    def _do_buy(self,player):
        itype,price=SHOP_ITEMS[self.cursor]
        if player.gold<price: player.msg("Ei tarpeeksi kultaa!",P["red"]); SFX.play("error"); return
        if len(player.inventory)>=8: player.msg("Inventaario täynnä!",P["red"]); SFX.play("error"); return
        player.gold-=price; info=ITEM_DEF[itype]
        if itype=="sword":   player.attack+=2; player.msg(f"Ostit {info[0]}: +2 ATK!",P["orange"]); SFX.play("shop")
        elif itype=="shield":player.defense+=1; player.msg(f"Ostit {info[0]}: +1 DEF!",P["blue"]); SFX.play("shop")
        else:
            if player.add_item(itype): player.msg(f"Ostit {info[0]}!",info[2]); SFX.play("shop")

    def handle_key(self,key,player):
        if not self.open: return False
        if key==pygame.K_ESCAPE: self.open=False; return True
        if key in(pygame.K_UP,pygame.K_w): self.cursor=(self.cursor-1)%len(SHOP_ITEMS); return True
        if key in(pygame.K_DOWN,pygame.K_s): self.cursor=(self.cursor+1)%len(SHOP_ITEMS); return True
        if key in(pygame.K_RETURN,pygame.K_SPACE): self._do_buy(player); return True
        return False

    def draw(self,screen,player,fonts,sprites):
        if not self.open: return
        x0,y0,W,H,rects=self.get_item_rects()
        surf=pygame.Surface((W,H),pygame.SRCALPHA); surf.fill((14,18,10,240))
        screen.blit(surf,(x0,y0))
        pygame.draw.rect(screen,P["gold"],(x0,y0,W,H),2,border_radius=8)
        t=fonts["med"].render("KAUPPIAS",True,P["gold"])
        screen.blit(t,(x0+W//2-t.get_width()//2,y0+12))
        gt=fonts["small"].render(f"Kultasi: {player.gold}G",True,P["gold"])
        screen.blit(gt,(x0+W-gt.get_width()-14,y0+42))
        # Sulje-X
        close_r=(x0+W-32,y0+6,28,28)
        mx2,my2=pygame.mouse.get_pos()
        hov_c=mouse_in(close_r,mx2,my2)
        pygame.draw.rect(screen,P["red"] if hov_c else P["panel2"],close_r,border_radius=5)
        xt=fonts["small"].render("X",True,P["white"])
        screen.blit(xt,(close_r[0]+close_r[2]//2-xt.get_width()//2,close_r[1]+5))
        pygame.draw.line(screen,P["gold"],(x0+10,y0+42),(x0+W-10,y0+42),1)

        for i,(itype,price) in enumerate(SHOP_ITEMS):
            info=ITEM_DEF[itype]; r=rects[i]
            sel=(i==self.cursor)
            hov=(i==self.hovered)
            bg=P["panel2"] if sel or hov else P["panel"]
            border=info[2] if sel else(P["gold"] if hov else P["border"])
            pygame.draw.rect(screen,bg,r,border_radius=6)
            pygame.draw.rect(screen,border,r,2 if sel else 1,border_radius=6)
            skey=itype if itype!="big_hp" else "health"
            if sprites.get(skey):
                img=pygame.transform.scale(sprites[skey],(34,34)); screen.blit(img,(r[0]+8,r[1]+8))
            else:
                ct=fonts["med"].render(info[3],True,info[2]); screen.blit(ct,(r[0]+12,r[1]+10))
            nt=fonts["small"].render(info[0],True,P["white"] if sel else P["text"])
            screen.blit(nt,(r[0]+50,r[1]+8))
            dt=fonts["tiny"].render(info[1],True,P["dim"])
            screen.blit(dt,(r[0]+50,r[1]+26))
            can=player.gold>=price
            pt=fonts["small"].render(f"{price}G",True,P["gold"] if can else P["red"])
            screen.blit(pt,(r[0]+W-pt.get_width()-30,r[1]+16))

        hint=fonts["tiny"].render("Klikkaa tai nuolet+ENTER ostaaksesi  |  ESC/X: sulje",True,P["dim"])
        screen.blit(hint,(x0+W//2-hint.get_width()//2,y0+H-22))

# ═══════════════════════════════════════════
#  SPRITE LATAUS
# ═══════════════════════════════════════════
def load_sprites():
    sp={}
    names=["floor","floor_dark","wall","wall_dark","stairs",
           "player","player_soturi","player_magi","player_varas",
           "goblin","orc","troll","skeleton","wizard","spider",
           "vampire","demon","golem","necromancer","wraith",
           "health","gold","sword","shield","xp","fog"]
    # Lisää boss-spritet kaikille bossitasoille
    for f in range(5,101,5):
        names.append(f"boss_{f}")
    for n in names:
        path=os.path.join(SPRITE_DIR,f"{n}.png")
        if os.path.exists(path):
            try: sp[n]=pygame.image.load(path).convert_alpha()
            except: sp[n]=None
        else: sp[n]=None
    return sp

# ═══════════════════════════════════════════
#  PÄÄPELILUOKKA
# ═══════════════════════════════════════════
class Game:
    def __init__(self):
        pygame.init()
        self.screen=pygame.display.set_mode((SCREEN_W,SCREEN_H))
        pygame.display.set_caption("Dungeon Crawler v4")
        self.clock=pygame.time.Clock()
        # Try to use a cleaner font, fall back to monospace
        def _font(size, bold=False):
            for name in ["segoeui","calibri","arial","verdana","monospace"]:
                try:
                    f=pygame.font.SysFont(name,size,bold=bold)
                    if f: return f
                except: pass
            return pygame.font.SysFont("monospace",size,bold=bold)
        self.fonts={
            "title":   _font(36, bold=True),
            "big":     _font(26, bold=True),
            "med":     _font(17, bold=True),
            "small":   _font(14),
            "tiny":    _font(12),
            "vfx":     _font(15, bold=True),
            "vfx_big": _font(24, bold=True),
            "panel_label": _font(11),
            "panel_val":   _font(13, bold=True),
        }
        self.sprites=load_sprites()
        self.inv_ui=InventoryUI(); self.shop_ui=ShopUI()
        self.floor=1; self.state="menu"
        self.vfx=[]; self.cam_x=self.cam_y=0
        self.player_class="Soturi"; self.player=None
        self.boss=None; self.boss_beaten=False

    # ─── Tason alustus ──────────────────────────────────────
    def new_level(self):
        is_boss_floor=(self.floor in BOSS_FLOORS)
        has_shop=(self.floor not in BOSS_FLOORS)
        self.tiles,self.explored,self.rooms,self.shop_room=generate_level(self.floor,has_shop,is_boss_floor)
        sx,sy=self.rooms[0].center()
        if self.floor==1:
            self.player=Player(sx,sy,self.player_class)
            cd=CLASS_DEF[self.player_class]
            self.player.msg(f"Olet {self.player_class}. Tervetuloa!",cd["color"])
            self.player.msg("E=inventaario  hiiri=klikkaa UI",P["dim"])
        else:
            # ★ HP tuplaantuu joka kerroksella!
            self.player.x,self.player.y=sx,sy
            self.player.max_hp = int(self.player.max_hp * 1.2)
            self.player.hp = self.player.max_hp
            th=FLOOR_THEMES.get(self.floor,FLOOR_THEMES[1])
            self.player.msg(f"Kerros {self.floor}: {th['name']} — MAX HP +20%!",P["green"])
            self.vfx.append(VFX(sx,sy,"HP +20%!",P["green"],80,True))
        self.enemies=self._spawn_enemies()
        self.boss=None
        self.vfx=[]
        if is_boss_floor:
            bc,br=self.rooms[-1].center()
            self.boss=Boss(bc,br,self.floor); self.enemies.append(self.boss)
            self.player.msg("VAARA! Bossi odottaa syvällä!",P["red"])
            SFX.play("boss")
        self.items=self._spawn_items()
        self.fov=[[False]*MAP_W for _ in range(MAP_H)]
        self._update_fov(); self._center_cam()

    def _spawn_enemies(self):
        f=self.floor
        pool=['goblin','skeleton']
        if f>=2:  pool+=['orc','spider']
        if f>=3:  pool+=['orc','troll']
        if f>=2:  pool+=['wizard']
        if f>=6:  pool+=['vampire','vampire']
        if f>=7:  pool+=['wraith','wraith']
        if f>=8:  pool+=['demon','demon','necromancer']
        if f>=9:  pool+=['golem','demon']
        if f>=10: pool+=['golem','necromancer','wraith']
        # bossikerroksilla vapaa viimeiset huoneet bossille
        is_boss=(f in BOSS_FLOORS)
        room_slice=self.rooms[1:-2 if is_boss else None]
        out=[]
        max_per_room=min(5,1+f//2)
        for room in room_slice:
            for _ in range(random.randint(0,max_per_room)):
                x,y=room.random_floor()
                out.append(Enemy(x,y,random.choice(pool),f))
        return out

    def _spawn_items(self):
        f=self.floor
        pool=['health','health','gold','gold','xp','bomb']
        if f>=2: pool+=['sword','shield']
        if f>=3: pool+=['big_hp','antidote']
        if f>=6: pool+=['big_hp','health','xp']
        if f>=8: pool+=['big_hp','bomb','xp']
        out=[]
        for room in self.rooms[1:]:
            if self.shop_room and room.center()==self.shop_room.center(): continue
            if random.random()<.6:
                x,y=room.random_floor()
                out.append(ItemObj(x,y,random.choice(pool)))
        return out

    def _update_fov(self):
        self.fov=compute_fov(self.tiles,self.player.x,self.player.y)
        for y in range(MAP_H):
            for x in range(MAP_W):
                if self.fov[y][x]: self.explored[y][x]=True

    def _center_cam(self):
        self.cam_x=max(0,min(self.player.x-VP_W//2,MAP_W-VP_W))
        self.cam_y=max(0,min(self.player.y-VP_H//2,MAP_H-VP_H))

    # ─── Liikkuminen ────────────────────────────────────────
    def try_move(self,dx,dy):
        if self.inv_ui.open or self.shop_ui.open: return
        p=self.player; nx,ny=p.x+dx,p.y+dy
        if not(0<=nx<MAP_W and 0<=ny<MAP_H): return
        if self.tiles[ny][nx]==WALL: return
        # Hyökkäys viholliseen
        for e in self.enemies:
            if e.alive and e.x==nx and e.y==ny:
                self._do_attack(p,e)
                if self.state in("dead","victory"): return
                self._enemy_turn()
                if self.state in("dead","victory"): return
                self._update_fov(); self._center_cam(); return
        # Liiku
        p.x,p.y=nx,ny; SFX.play("step")
        # Poimi esineet
        for item in self.items[:]:
            if item.x==nx and item.y==ny:
                self._pick_item(item); self.items.remove(item); p.items_collected+=1
        tile=self.tiles[ny][nx]
        # Portaat
        if tile==STAIRS:
            SFX.play("stairs"); self.floor+=1
            if self.floor>MAX_FLOOR: self._end_game("victory")
            else: self.new_level()
            return
        # Kauppa
        if tile==SHOP_TILE:
            self.shop_ui.open=True; SFX.play("shop")
            p.msg("Kauppias: tervetuloa!",P["gold"])
        # Myrkky
        if p.poisoned>0:
            p.poisoned-=1; p.hp=max(1,p.hp-1)
            if p.hp<=0:
                self._end_game("dead"); return
            if p.poisoned==0: p.msg("Myrkky loppui.",P["cyan"])
        self._enemy_turn()
        if self.state in("dead","victory"): return
        self._update_fov(); self._center_cam()

    def _do_attack(self,attacker,target):
        base=attacker.attack+random.randint(0,3)
        crit=False
        if hasattr(attacker,'cls') and attacker.cls=="Varas" and random.random()<.25:
            base*=2; crit=True
        # Bossi faasitarkistus
        if isinstance(target,Boss):
            actual=target.take_damage(base)
            if not target.alive:
                changed=target.check_phase()
                if changed:
                    self.vfx.append(VFX(target.x,target.y,"FAASI 2!",P["red"],90,True))
                    self.player.msg("Bossi muuttui! Faasi 2!",P["red"]); SFX.play("boss")
                    target.alive=True
        else:
            actual=target.take_damage(base)
        col=P["gold"] if crit else P["orange"]
        self.vfx.append(VFX(target.x,target.y,f"KRIITTI! -{actual}" if crit else f"-{actual}",col,55,crit))
        SFX.play("hit")
        if isinstance(attacker,Player):
            self.player.msg(f"Iskut {target.name}: {actual}",col)
            if not target.alive:
                self.player.kills+=1
                self.player.gain_xp(target.xp_reward)
                if isinstance(target,Boss):
                    self.player.msg("BOSSI KUKISTETTU! Etsi portaat!",P["gold"])
                    self.vfx.append(VFX(target.x,target.y,"VOITTO!",P["gold"],120,True))
                    SFX.play("levelup")
                else:
                    self.player.msg(f"{target.name} kaatui! +{target.xp_reward}XP",P["green"])
                    SFX.play("die")
                if random.random()<.3:
                    drops=['health','gold','xp']
                    self.items.append(ItemObj(target.x,target.y,random.choice(drops)))

    def _pick_item(self,item):
        p=self.player
        if item.itype in("sword","shield","gold"):
            if item.itype=="sword":
                p.attack+=2; p.msg(f"Löysit {item.name}: +2 ATK!",P["orange"]); SFX.play("pickup")
                self.vfx.append(VFX(item.x,item.y,"+2 ATK",P["orange"]))
            elif item.itype=="shield":
                p.defense+=1; p.msg(f"Löysit {item.name}: +1 DEF!",P["blue"]); SFX.play("pickup")
                self.vfx.append(VFX(item.x,item.y,"+1 DEF",P["blue"]))
            elif item.itype=="gold":
                g=random.randint(10,25); p.gold+=g
                p.msg(f"Kultaa: +{g}G",P["gold"]); SFX.play("gold")
                self.vfx.append(VFX(item.x,item.y,f"+{g}G",P["gold"]))
        else:
            if p.add_item(item.itype):
                p.msg(f"Poimit: {item.name}",item.color); SFX.play("pickup")
                self.vfx.append(VFX(item.x,item.y,f"+{item.name[:6]}",item.color))
            else:
                p.msg("Inventaario täynnä! (E)",P["red"]); SFX.play("error")

    def _enemy_turn(self):
        p=self.player
        for e in self.enemies:
            if not e.alive: continue
            if isinstance(e,Boss): e.tick_rage()
            dist=math.hypot(e.x-p.x,e.y-p.y)
            if self.fov[e.y][e.x]: e.saw_player=True
            if not e.saw_player: continue
            if dist<=1.5:
                dmg=e.attack+random.randint(0,3)
                actual=p.take_damage(dmg); SFX.play("player_hit")
                self.vfx.append(VFX(p.x,p.y,f"-{actual}",P["red"],45))
                lbl=f"{e.name} iskee: -{actual} HP"
                if hasattr(e,'etype') and e.etype=="spider" and random.random()<.4:
                    p.poisoned=max(p.poisoned,6); lbl+=" MYRKYTYS!"
                    self.vfx.append(VFX(p.x,p.y,"MYRKKY!",P["cyan"],60,True))
                p.msg(lbl,P["red"])
                if not p.alive: self._end_game("dead"); return
            else:
                rng=8 if(hasattr(e,'ranged') and e.ranged) else 14
                if dist<rng:
                    if hasattr(e,'ranged') and e.ranged and dist<5: self._flee(e)
                    else: self._chase(e)

    def _chase(self,e):
        dx=(int(math.copysign(1,self.player.x-e.x)) if self.player.x!=e.x else 0)
        dy=(int(math.copysign(1,self.player.y-e.y)) if self.player.y!=e.y else 0)
        opts=[(dx,dy),(dx,0),(0,dy),(-dy,dx),(dy,-dx)]; random.shuffle(opts)
        for sdx,sdy in opts:
            if sdx==sdy==0: continue
            nx,ny=e.x+sdx,e.y+sdy
            if(0<=nx<MAP_W and 0<=ny<MAP_H and self.tiles[ny][nx]!=WALL
               and not any(en.alive and en.x==nx and en.y==ny and en!=e for en in self.enemies)
               and not(nx==self.player.x and ny==self.player.y)):
                e.x,e.y=nx,ny; break

    def _flee(self,e):
        dx=(int(math.copysign(1,e.x-self.player.x)) if self.player.x!=e.x else 0)
        dy=(int(math.copysign(1,e.y-self.player.y)) if self.player.y!=e.y else 0)
        for sdx,sdy in[(dx,dy),(dx,0),(0,dy)]:
            nx,ny=e.x+sdx,e.y+sdy
            if 0<=nx<MAP_W and 0<=ny<MAP_H and self.tiles[ny][nx]!=WALL:
                e.x,e.y=nx,ny; break

    def _end_game(self,result):
        self.state=result  # "dead" tai "victory" — run() hoitaa name entry

    # ═══════════════════════════════════════
    #  PIIRTO
    # ═══════════════════════════════════════
    def draw(self):
        theme=FLOOR_THEMES.get(self.floor,FLOOR_THEMES[1])
        self.screen.fill(P["bg"])
        cx,cy=self.cam_x,self.cam_y; sp=self.sprites

        for ty in range(VP_H+1):
            for tx in range(VP_W+1):
                mx2,my2=cx+tx,cy+ty
                if not(0<=mx2<MAP_W and 0<=my2<MAP_H): continue
                sx2,sy2=tx*TILE,ty*TILE
                tile=self.tiles[my2][mx2]; vis=self.fov[my2][mx2]; expl=self.explored[my2][mx2]
                if not expl:
                    pygame.draw.rect(self.screen,(4,3,8),(sx2,sy2,TILE,TILE)); continue
                if tile==WALL:
                    if sp.get("wall" if vis else "wall_dark"):
                        img=sp["wall" if vis else "wall_dark"].copy()
                        # Kerrosteema väritys
                        tint_col=theme["wall"]
                        tsurf=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                        tsurf.fill((*tint_col,60)); img.blit(tsurf,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
                        self.screen.blit(img,(sx2,sy2))
                    else:
                        c=theme["wall"] if vis else tuple(max(0,v-30) for v in theme["wall"])
                        pygame.draw.rect(self.screen,c,(sx2,sy2,TILE,TILE))
                elif tile==STAIRS and vis:
                    if sp.get("floor"): self.screen.blit(sp["floor"],(sx2,sy2))
                    if sp.get("stairs"): self.screen.blit(sp["stairs"],(sx2,sy2))
                    else:
                        pygame.draw.rect(self.screen,theme["floor"],(sx2,sy2,TILE,TILE))
                        t2=self.fonts["big"].render(">",True,P["gold"]); self.screen.blit(t2,(sx2+6,sy2+2))
                elif tile==SHOP_TILE and vis:
                    if sp.get("floor"): self.screen.blit(sp["floor"],(sx2,sy2))
                    t2=self.fonts["small"].render("$",True,P["gold"]); self.screen.blit(t2,(sx2+9,sy2+7))
                else:
                    if sp.get("floor" if vis else "floor_dark"):
                        img=sp["floor" if vis else "floor_dark"].copy()
                        tsurf=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                        fc=theme["floor"]; tsurf.fill((*fc,50))
                        img.blit(tsurf,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
                        self.screen.blit(img,(sx2,sy2))
                    else:
                        c=theme["floor"] if vis else tuple(max(0,v-20) for v in theme["floor"])
                        pygame.draw.rect(self.screen,c,(sx2,sy2,TILE,TILE))
                if not vis and expl:
                    fog=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                    fog.fill(theme["fog"]); self.screen.blit(fog,(sx2,sy2))

        # Kerrosteema-tint koko näkymälle
        if theme["tint"]:
            ts=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA)
            ts.fill(theme["tint"]); self.screen.blit(ts,(0,0))

        # Esineet
        for item in self.items:
            if not self.fov[item.y][item.x]: continue
            ix=(item.x-cx)*TILE; iy=(item.y-cy)*TILE
            bob=int(math.sin(item.bob_t+pygame.time.get_ticks()*.003)*2); item.bob_t+=.05
            k=item.itype if item.itype!="big_hp" else "health"
            if sp.get(k): self.screen.blit(sp[k],(ix,iy+bob))
            else:
                t2=self.fonts["med"].render(item.char,True,item.color); self.screen.blit(t2,(ix+8,iy+5+bob))

        # Viholliset
        for e in self.enemies:
            if not e.alive or not self.fov[e.y][e.x]: continue
            ex=(e.x-cx)*TILE; ey=(e.y-cy)*TILE
            bob=int(math.sin(e.anim_t)*1); e.update()
            is_boss=isinstance(e,Boss)
            if is_boss:
                # Hae bossispriten tason mukaan
                boss_key=f"boss_{e.floor_num}"
                if sp.get(boss_key):
                    img=sp[boss_key].copy()
                    # Väripulssi bosstintin mukaan
                    pulse=int(abs(math.sin(pygame.time.get_ticks()*.003))*60)
                    tint=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                    tc=tuple(min(255,v//3+pulse//3) for v in e.col)
                    tint.fill((*tc,80))
                    img.blit(tint,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
                    if e.flash>0:
                        fs=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                        fs.fill((255,255,255,min(200,e.flash*20)))
                        img.blit(fs,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
                    self.screen.blit(img,(ex,ey+bob))
                    # Hehkuva bossirengas
                    pygame.draw.rect(self.screen,e.col,(ex-1,ey+bob-1,TILE+2,TILE+2),2,border_radius=4)
                else:
                    # Fallback: iso väriruutu pulssilla
                    pulse=int(abs(math.sin(pygame.time.get_ticks()*.003))*30)
                    bc=tuple(min(255,v+pulse) for v in e.col)
                    pygame.draw.rect(self.screen,bc,(ex,ey+bob,TILE,TILE),border_radius=4)
                    pygame.draw.rect(self.screen,P["red"],(ex,ey+bob,TILE,TILE),2,border_radius=4)
                    bt=self.fonts["small"].render("B",True,P["white"])
                    self.screen.blit(bt,(ex+TILE//2-bt.get_width()//2,ey+bob+8))
            elif sp.get(e.etype):
                img=sp[e.etype].copy()
                if e.flash>0:
                    fs=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                    fs.fill((255,255,255,min(200,e.flash*20)))
                    img.blit(fs,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
                self.screen.blit(img,(ex,ey+bob))
            else:
                cm={'goblin':(50,180,50),'orc':(180,80,30),'troll':(100,150,50),
                    'skeleton':(210,205,190),'wizard':(160,50,200),'spider':(160,80,200)}
                t2=self.fonts["big"].render(e.etype[0].upper(),True,cm.get(e.etype,P["white"]))
                self.screen.blit(t2,(ex+7,ey+3+bob))

            # HP-palkki (bossi leveämpi)
            bw2=TILE*2 if is_boss else TILE-4; bx2=ex+2 if not is_boss else ex-TILE//2; by2=ey-6
            pygame.draw.rect(self.screen,(55,18,18),(bx2,by2,bw2,4))
            fw2=int(bw2*e.hp/max(1,e.max_hp))
            hc2=P["hp_hi"] if e.hp>e.max_hp*.6 else(P["hp_mid"] if e.hp>e.max_hp*.3 else P["hp_lo"])
            pygame.draw.rect(self.screen,hc2,(bx2,by2,fw2,4))
            if is_boss:
                bnt=self.fonts["tiny"].render(f"{e.name} {e.hp}/{e.max_hp}",True,P["red"])
                self.screen.blit(bnt,(ex-TILE//2,by2-14))

        # Pelaaja — luokkakohtainen sprite
        p=self.player; p.update()
        ppx=(p.x-cx)*TILE; ppy=(p.y-cy)*TILE
        cls_key=f"player_{p.cls.lower()}"
        player_sprite=sp.get(cls_key) or sp.get("player")
        if player_sprite:
            img=player_sprite.copy()
            if p.flash>0:
                fs=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
                fs.fill((255,80,80,min(200,p.flash*20)))
                img.blit(fs,(0,0),special_flags=pygame.BLEND_RGBA_ADD)
            self.screen.blit(img,(ppx,ppy))
        else:
            cd2=CLASS_DEF[p.cls]
            t2=self.fonts["big"].render(cd2["icon"],True,cd2["color"])
            self.screen.blit(t2,(ppx+5,ppy+2))

        # Myrkky overlay
        if p.poisoned>0:
            ps=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA)
            a=int(30+15*math.sin(pygame.time.get_ticks()*.005))
            ps.fill((40,200,80,a)); self.screen.blit(ps,(0,0))

        # VFX
        self.vfx=[v for v in self.vfx if v.update()]
        for v in self.vfx: v.draw(self.screen,self.fonts,cx,cy)

        self._draw_panel(); self._draw_bottom_bar()
        self.inv_ui.draw(self.screen,p,self.fonts,sp)
        self.shop_ui.draw(self.screen,p,self.fonts,sp)

    def _draw_panel(self):
        p=self.player; px0=GAME_W; pw=PANEL_W
        theme=FLOOR_THEMES.get(self.floor,FLOOR_THEMES[1])
        cd=CLASS_DEF[p.cls]
        sp=self.sprites
        mx2,my2=pygame.mouse.get_pos()

        # Taustat
        pygame.draw.rect(self.screen,(12,10,20),(px0,0,pw,SCREEN_H))
        # Teemaväriviivoitus ylhäällä
        th_col=theme["wall"]
        pygame.draw.rect(self.screen,th_col,(px0,0,pw,5))
        pygame.draw.rect(self.screen,tuple(min(255,v+40) for v in th_col),(px0,0,pw,2))
        pygame.draw.line(self.screen,(40,35,55),(px0,0),(px0,SCREEN_H),2)

        # ── Apufunktiot ─────────────────────────
        def shadow_text(txt, x, y, col, font, shadow_col=(0,0,0)):
            sh=font.render(txt,True,shadow_col)
            self.screen.blit(sh,(x+1,y+1))
            s=font.render(txt,True,col)
            self.screen.blit(s,(x,y))

        def bar(x,y,w,h,ratio,col,bg=(25,18,35)):
            # Taustavarjo
            pygame.draw.rect(self.screen,(0,0,0),(x+1,y+1,w,h),border_radius=3)
            pygame.draw.rect(self.screen,bg,(x,y,w,h),border_radius=3)
            fw=int(w*max(0,min(1,ratio)))
            if fw:
                # Gradientti-efekti
                light=tuple(min(255,v+50) for v in col)
                pygame.draw.rect(self.screen,col,(x,y,fw,h),border_radius=3)
                pygame.draw.rect(self.screen,light,(x,y,fw,h//3+1),border_radius=3)
            pygame.draw.rect(self.screen,(60,50,75),(x,y,w,h),1,border_radius=3)

        def sep(y,bright=False):
            c=(60,50,75) if not bright else(100,85,120)
            pygame.draw.line(self.screen,c,(px0+6,y),(SCREEN_W-6,y),1)

        ox=px0+10; bw=pw-20; oy=10

        # ── Hahmokortti ────────────────────────
        # Luokkavärikortti taustan
        card_col=tuple(v//4 for v in cd["color"])
        pygame.draw.rect(self.screen,card_col,(px0,6,pw,58),border_radius=4)
        pygame.draw.rect(self.screen,tuple(v//2 for v in cd["color"]),(px0,6,pw,58),1,border_radius=4)

        # Iso 64x64 hahmokuva vasemmalla
        portrait_size=52
        portrait_key=f"player_{p.cls.lower()}"
        portrait=sp.get(portrait_key) or sp.get("player")
        if portrait:
            big_portrait=pygame.transform.scale(portrait,(portrait_size,portrait_size))
            # Kehys
            pygame.draw.rect(self.screen,(40,35,55),(ox-2,oy-2,portrait_size+4,portrait_size+4),border_radius=4)
            pygame.draw.rect(self.screen,cd["color"],(ox-2,oy-2,portrait_size+4,portrait_size+4),2,border_radius=4)
            self.screen.blit(big_portrait,(ox,oy))
        else:
            pygame.draw.rect(self.screen,(30,25,45),(ox,oy,portrait_size,portrait_size),border_radius=4)
            pygame.draw.rect(self.screen,cd["color"],(ox,oy,portrait_size,portrait_size),2,border_radius=4)
            ic=self.fonts["title"].render(cd["icon"],True,cd["color"])
            self.screen.blit(ic,(ox+portrait_size//2-ic.get_width()//2,oy+10))

        # Nimi ja taso oikealla
        tx=ox+portrait_size+8
        shadow_text(p.cls, tx, oy+2, P["white"], self.fonts["med"])
        shadow_text(f"Taso  {p.level}", tx, oy+20, cd["color"], self.fonts["panel_val"])
        shadow_text(theme["name"], tx, oy+36, tuple(min(255,v+80) for v in th_col), self.fonts["panel_label"])
        oy+=62; sep(oy,True); oy+=8

        # ── HP-palkki ─────────────────────────
        hc=P["hp_hi"] if p.hp>p.max_hp*.5 else(P["hp_mid"] if p.hp>p.max_hp*.25 else P["hp_lo"])
        shadow_text("TERVEYS", ox, oy, P["dim"], self.fonts["panel_label"])
        hp_pct=f"{p.hp} / {p.max_hp}"
        hp_t=self.fonts["panel_label"].render(hp_pct,True,hc)
        self.screen.blit(hp_t,(SCREEN_W-hp_t.get_width()-12,oy))
        oy+=13
        bar(ox,oy,bw,16,p.hp/max(1,p.max_hp),hc)
        # HP teksti palkin päällä
        ht=self.fonts["panel_label"].render(f"{p.hp}/{p.max_hp}",True,(0,0,0))
        self.screen.blit(ht,(ox+bw//2-ht.get_width()//2,oy+1))
        oy+=20

        # ── XP-palkki ─────────────────────────
        shadow_text("KOKEMUS", ox, oy, P["dim"], self.fonts["panel_label"])
        oy+=13
        bar(ox,oy,bw,10,p.xp/max(1,p.xp_next),P["xp"])
        xt=self.fonts["panel_label"].render(f"{p.xp}/{p.xp_next}",True,(0,0,0))
        self.screen.blit(xt,(ox+bw//2-xt.get_width()//2,oy+1))
        oy+=16; sep(oy); oy+=8

        # ── Tilastot kahdessa sarakkeessa ─────
        stats_left =[("⚔  ATK", f"{p.attack}", P["orange"]),
                     ("🛡  DEF", f"{p.defense}", P["blue"])]
        stats_right=[("💰 Kulta",f"{p.gold}G",  P["gold"]),
                     ("💀 Tapot",f"{p.kills}",   P["dim"])]
        col_w=bw//2-4
        for i,(lbl2,val,col) in enumerate(stats_left):
            sy2=oy+i*22
            pygame.draw.rect(self.screen,(20,16,30),(ox,sy2,col_w,18),border_radius=3)
            shadow_text(lbl2, ox+4, sy2+2, P["dim"], self.fonts["panel_label"])
            shadow_text(val,  ox+col_w-self.fonts["panel_val"].size(val)[0]-4, sy2+2, col, self.fonts["panel_val"])
        for i,(lbl2,val,col) in enumerate(stats_right):
            sx3=ox+col_w+8; sy2=oy+i*22
            pygame.draw.rect(self.screen,(20,16,30),(sx3,sy2,col_w,18),border_radius=3)
            shadow_text(lbl2, sx3+4, sy2+2, P["dim"], self.fonts["panel_label"])
            shadow_text(val,  sx3+col_w-self.fonts["panel_val"].size(val)[0]-4, sy2+2, col, self.fonts["panel_val"])
        oy+=48

        # Myrkky & kerros
        if p.poisoned>0:
            pygame.draw.rect(self.screen,(0,40,20),(ox,oy,bw,18),border_radius=3)
            shadow_text(f"⚗ MYRKKY  {p.poisoned} vuoroa",ox+4,oy+2,P["cyan"],self.fonts["panel_label"])
            oy+=22
        shadow_text(f"KERROS  {self.floor} / {MAX_FLOOR}", ox, oy, P["dim"], self.fonts["panel_label"])
        oy+=18; sep(oy); oy+=8

        # ── Inventaariopainike + pikaslotit ───
        inv_btn_rect=(ox,oy,bw,20)
        hov_inv=mouse_in(inv_btn_rect,mx2,my2)
        bg_inv=(30,24,50) if hov_inv else(22,18,36)
        border_inv=P["gold"] if hov_inv else(50,42,68)
        pygame.draw.rect(self.screen,bg_inv,inv_btn_rect,border_radius=4)
        pygame.draw.rect(self.screen,border_inv,inv_btn_rect,1,border_radius=4)
        inv_label=f"REPPU  {len(p.inventory)}/8   [E]"
        shadow_text(inv_label, ox+bw//2-self.fonts["panel_label"].size(inv_label)[0]//2,
                    oy+3, P["gold"] if p.inventory else P["dim"], self.fonts["panel_label"])
        oy+=26

        ss=44; gap=4
        self.slot_rects_panel=[]
        for i in range(4):
            sx2=ox+i*(ss+gap); sy2=oy
            has=i<len(p.inventory)
            hov_s=mouse_in((sx2,sy2,ss,ss),mx2,my2)
            # Slot tausta
            slot_bg=(28,22,45) if has else(16,13,26)
            pygame.draw.rect(self.screen,(0,0,0),(sx2+1,sy2+1,ss,ss),border_radius=5)
            pygame.draw.rect(self.screen,slot_bg,(sx2,sy2,ss,ss),border_radius=5)
            slot_border=P["gold"] if(hov_s and has) else((55,44,75) if has else(30,25,42))
            pygame.draw.rect(self.screen,slot_border,(sx2,sy2,ss,ss),2 if(hov_s and has) else 1,border_radius=5)
            # Numero
            num=self.fonts["panel_label"].render(str(i+1),True,(60,50,75))
            self.screen.blit(num,(sx2+3,sy2+2))
            if has:
                it2=p.inventory[i]; info2=ITEM_DEF[it2]
                sk=it2 if it2!="big_hp" else "health"
                if self.sprites.get(sk):
                    img=pygame.transform.scale(self.sprites[sk],(30,30))
                    self.screen.blit(img,(sx2+7,sy2+11))
                else:
                    ct=self.fonts["small"].render(info2[3],True,info2[2])
                    self.screen.blit(ct,(sx2+ss//2-ct.get_width()//2,sy2+14))
                # Hover tooltip
                if hov_s:
                    # Tooltip-ruutu
                    tip=info2[0]; tip_f=self.fonts["panel_label"]
                    tw=tip_f.size(tip)[0]+8; th2=tip_f.size(tip)[1]+4
                    tx2=max(px0+4, sx2+ss//2-tw//2)
                    pygame.draw.rect(self.screen,(20,16,30),(tx2,sy2-th2-2,tw,th2),border_radius=3)
                    pygame.draw.rect(self.screen,info2[2],(tx2,sy2-th2-2,tw,th2),1,border_radius=3)
                    shadow_text(tip,tx2+4,sy2-th2,info2[2],tip_f)
            self.slot_rects_panel.append((sx2,sy2,ss,ss))
        oy+=ss+6; sep(oy); oy+=6

        # ── Minikartta ────────────────────────
        shadow_text("KARTTA", ox, oy, (130,120,150), self.fonts["panel_label"]); oy+=14
        ms=max(1,bw//MAP_W); mw=MAP_W*ms; mh=MAP_H*ms
        mini=pygame.Surface((mw,mh)); mini.fill((4,3,8))
        for my3 in range(MAP_H):
            for mx3 in range(MAP_W):
                if not self.explored[my3][mx3]: continue
                t3=self.tiles[my3][mx3]
                col=(70,60,50) if t3==WALL else(110,95,78)
                if t3==STAIRS: col=P["gold"]
                if t3==SHOP_TILE: col=(50,180,50)
                if self.fov[my3][mx3] and t3!=WALL: col=(148,130,108)
                pygame.draw.rect(mini,col,(mx3*ms,my3*ms,ms,ms))
        for e in self.enemies:
            if e.alive and self.fov[e.y][e.x]:
                c=P["red"] if not isinstance(e,Boss) else(255,100,0)
                pygame.draw.rect(mini,c,(e.x*ms,e.y*ms,ms+1,ms+1))
        pygame.draw.rect(mini,P["white"],(p.x*ms,p.y*ms,ms+1,ms+1))
        # Kehys kartalle
        pygame.draw.rect(self.screen,(0,0,0),(ox+1,oy+1,mw,mh))
        self.screen.blit(mini,(ox,oy))
        pygame.draw.rect(self.screen,(50,42,68),(ox,oy,mw,mh),1)
        oy+=mh+8; sep(oy); oy+=5

        # ── Viestiloki ────────────────────────
        shadow_text("LOKI", ox, oy, (130,120,150), self.fonts["panel_label"]); oy+=14
        msgs=p.messages[-5:]
        for i,(msg,col) in enumerate(msgs):
            alpha=80+int(175*(i+1)/len(msgs))
            # Taustasuikale luettavuuden parantamiseksi
            msg_f=self.fonts["panel_label"]
            tw2=msg_f.size(msg[:28])[0]
            bg_surf=pygame.Surface((tw2+4,14),pygame.SRCALPHA)
            bg_surf.fill((0,0,0,80))
            self.screen.blit(bg_surf,(ox-2,oy))
            s=msg_f.render(msg[:28],True,col); s.set_alpha(alpha)
            self.screen.blit(s,(ox,oy+1)); oy+=15

    def _draw_bottom_bar(self):
        by=GAME_H; bh=SCREEN_H-by
        pygame.draw.rect(self.screen,(10,8,18),(0,by,GAME_W,bh))
        pygame.draw.rect(self.screen,(0,0,0),(0,by,GAME_W,1))
        pygame.draw.line(self.screen,(45,38,60),(0,by),(GAME_W,by),1)
        keys=[("WASD","Liiku"),("E","Inventaario"),("1-8","Käytä"),("ESC","Valikko")]
        kx=10
        for k,v in keys:
            # Näppäin-badge
            kf=self.fonts["panel_label"]; vf=self.fonts["panel_label"]
            kw=kf.size(k)[0]+8; vw=vf.size(v)[0]
            pygame.draw.rect(self.screen,(40,35,58),(kx,by+8,kw,18),border_radius=3)
            pygame.draw.rect(self.screen,(70,60,90),(kx,by+8,kw,18),1,border_radius=3)
            ks=kf.render(k,True,(220,210,240)); self.screen.blit(ks,(kx+4,by+10))
            kx+=kw+4
            vs=vf.render(v,True,(110,100,130)); self.screen.blit(vs,(kx,by+10))
            kx+=vw+18
        if self.player and self.player.poisoned>0:
            pf=self.fonts["panel_val"]
            pw2=pf.size(f"☠ MYRKKY {self.player.poisoned}")[0]+12
            pygame.draw.rect(self.screen,(0,50,20),(GAME_W-pw2-8,by+5,pw2,22),border_radius=4)
            pygame.draw.rect(self.screen,P["cyan"],(GAME_W-pw2-8,by+5,pw2,22),1,border_radius=4)
            w=pf.render(f"☠ MYRKKY {self.player.poisoned}",True,P["cyan"])
            self.screen.blit(w,(GAME_W-pw2-2,by+8))

    def draw_overlay(self):
        surf=pygame.Surface((SCREEN_W,SCREEN_H),pygame.SRCALPHA)
        surf.fill((0,0,0,210)); self.screen.blit(surf,(0,0))
        p=self.player
        if self.state=="dead":
            t1=self.fonts["title"].render("KUOLIT!",True,P["red"])
        else:
            t1=self.fonts["title"].render("VOITIT!",True,P["gold"])
        sc=calc_score(p,self.floor)
        t2=self.fonts["med"].render(f"Pisteet: {sc}",True,P["white"])
        stats=[(f"Luokka: {p.cls}",CLASS_DEF[p.cls]["color"]),
               (f"Tapettu: {p.kills}",P["orange"]),
               (f"Kulta: {p.gold}",P["gold"]),
               (f"Taso: {p.level}",P["xp"])]
        mx2=SCREEN_W//2; cy=SCREEN_H//2-130
        self.screen.blit(t1,(mx2-t1.get_width()//2,cy)); cy+=55
        self.screen.blit(t2,(mx2-t2.get_width()//2,cy)); cy+=45
        for st,sc2 in stats:
            s=self.fonts["med"].render(st,True,sc2)
            self.screen.blit(s,(mx2-s.get_width()//2,cy)); cy+=32
        cy+=14
        hint=self.fonts["med"].render("R = Uusi peli     M = Päävalikko     ESC = Lopeta",True,P["dim"])
        self.screen.blit(hint,(mx2-hint.get_width()//2,cy))

    # ═══════════════════════════════════════
    #  PÄÄSILMUKKA
    # ═══════════════════════════════════════
    async def run(self):
        # UI-tila: menu, scores, help, classselect, playing, dead, victory, nameentry
        ui="menu"
        cls_sel=0; help_page=0; name_buf=""
        pending_score=None  # (score,cls,floor,kills)
        game_result=None    # "dead" tai "victory"

        while True:
            self.clock.tick(FPS)
            mx,my=pygame.mouse.get_pos()

            # ── Tapahtumat ──────────────────────────────
            for ev in pygame.event.get():
                if ev.type==pygame.QUIT: pygame.quit(); raise SystemExit

                if ev.type==pygame.MOUSEMOTION:
                    if ui=="playing":
                        self.inv_ui.handle_mouse(ev.pos[0],ev.pos[1],self.player,self.enemies,self.fov)
                        self.shop_ui.handle_mouse(ev.pos[0],ev.pos[1])

                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    if ui=="menu":
                        rects=main_menu(self.screen,self.fonts,mx,my)
                        for rect,action in rects:
                            if mouse_in(rect,*ev.pos):
                                SFX.play("menu_sel")
                                if action=="quit": pygame.quit(); raise SystemExit
                                elif action=="scores": ui="scores"
                                elif action=="help": ui="help"; help_page=0
                                elif action=="newgame": ui="classselect"; cls_sel=0
                    elif ui=="scores":
                        ui="menu"
                    elif ui=="help":
                        pr,nr,br,tabs=help_screen(self.screen,self.fonts,help_page,mx,my)
                        if mouse_in(br,*ev.pos): SFX.play("menu_sel"); ui="menu"
                        elif mouse_in(pr,*ev.pos) and help_page>0: SFX.play("menu_sel"); help_page-=1
                        elif mouse_in(nr,*ev.pos) and help_page<len(HELP_PAGES)-1: SFX.play("menu_sel"); help_page+=1
                        else:
                            for i,r in enumerate(tabs):
                                if mouse_in(r,*ev.pos): SFX.play("menu_sel"); help_page=i; break
                    elif ui=="classselect":
                        crects,ckeys=class_select_screen(self.screen,self.fonts,cls_sel,mx,my)
                        for i,r in enumerate(crects):
                            if mouse_in(r,*ev.pos):
                                SFX.play("menu_sel"); self.player_class=ckeys[i]
                                self.floor=1; self.state="playing"; self.new_level(); ui="playing"
                    elif ui in("dead","victory"):
                        pass  # handled by keydown
                    elif ui=="nameentry":
                        pass
                    elif ui=="playing":
                        if self.inv_ui.open:
                            self.inv_ui.handle_click(ev.pos[0],ev.pos[1],self.player,self.enemies,self.fov); continue
                        if self.shop_ui.open:
                            self.shop_ui.handle_click(ev.pos[0],ev.pos[1],self.player); continue
                        if hasattr(self,'slot_rects_panel'):
                            for i,r in enumerate(self.slot_rects_panel):
                                if mouse_in(r,ev.pos[0],ev.pos[1]) and i<len(self.player.inventory):
                                    self.player.use_item(i,self.enemies,self.fov); break
                        if GAME_W<=ev.pos[0]<=SCREEN_W: self.inv_ui.open=True

                if ev.type==pygame.KEYDOWN:
                    if ui=="menu":
                        if ev.key in(pygame.K_RETURN,pygame.K_SPACE): ui="classselect"; cls_sel=0
                        if ev.key==pygame.K_ESCAPE: pygame.quit(); raise SystemExit
                    elif ui=="scores":
                        if ev.key==pygame.K_ESCAPE: ui="menu"
                    elif ui=="help":
                        if ev.key==pygame.K_ESCAPE: ui="menu"
                        if ev.key in(pygame.K_LEFT,pygame.K_a) and help_page>0: help_page-=1
                        if ev.key in(pygame.K_RIGHT,pygame.K_d) and help_page<len(HELP_PAGES)-1: help_page+=1
                    elif ui=="classselect":
                        keys=list(CLASS_DEF.keys())
                        if ev.key in(pygame.K_LEFT,pygame.K_a): cls_sel=(cls_sel-1)%len(keys)
                        if ev.key in(pygame.K_RIGHT,pygame.K_d): cls_sel=(cls_sel+1)%len(keys)
                        if ev.key in(pygame.K_RETURN,pygame.K_SPACE):
                            SFX.play("menu_sel"); self.player_class=keys[cls_sel]
                            self.floor=1; self.state="playing"; self.new_level(); ui="playing"
                        if ev.key==pygame.K_ESCAPE: ui="menu"
                    elif ui=="nameentry":
                        if pending_score:
                            sc2,cls2,fl,kl=pending_score
                            if ev.key==pygame.K_RETURN:
                                n=name_buf.strip()
                                if not n: n="Pelaaja"
                                save_score(n[:14],sc2,cls2,fl,kl)
                                pending_score=None
                                ui=game_result if game_result else "menu"
                            elif ev.key==pygame.K_BACKSPACE: name_buf=name_buf[:-1]
                            elif len(name_buf)<14 and ev.unicode.isprintable(): name_buf+=ev.unicode
                    elif ui in("dead","victory"):
                        if ev.key==pygame.K_r: ui="classselect"; cls_sel=0; self.state="menu"
                        elif ev.key==pygame.K_m: ui="menu"; self.state="menu"
                        elif ev.key==pygame.K_ESCAPE: pygame.quit(); raise SystemExit
                    elif ui=="playing":
                        if self.shop_ui.open:
                            self.shop_ui.handle_key(ev.key,self.player); continue
                        if ev.key==pygame.K_ESCAPE:
                            if self.inv_ui.open: self.inv_ui.open=False
                            else: ui="menu"; self.state="menu"
                            continue
                        if ev.key==pygame.K_e: self.inv_ui.toggle(); continue
                        num_keys={pygame.K_1:0,pygame.K_2:1,pygame.K_3:2,pygame.K_4:3,
                                   pygame.K_5:4,pygame.K_6:5,pygame.K_7:6,pygame.K_8:7}
                        if ev.key in num_keys:
                            idx=num_keys[ev.key]
                            ok=self.player.use_item(idx,self.enemies,self.fov)
                            if not ok and idx<len(self.player.inventory):
                                self.player.msg("Ei voi käyttää suoraan!",P["dim"])
                            continue
                        if not self.inv_ui.open:
                            moves={pygame.K_UP:(0,-1),pygame.K_w:(0,-1),
                                   pygame.K_DOWN:(0,1),pygame.K_s:(0,1),
                                   pygame.K_LEFT:(-1,0),pygame.K_a:(-1,0),
                                   pygame.K_RIGHT:(1,0),pygame.K_d:(1,0)}
                            if ev.key in moves: self.try_move(*moves[ev.key])

            # Tarkista pelin päättyminen
            if ui=="playing" and self.state in("dead","victory"):
                game_result=self.state
                sc2=calc_score(self.player,self.floor)
                pending_score=(sc2,self.player.cls,self.floor,self.player.kills)
                name_buf=""; ui="nameentry"

            # ── Piirto ──────────────────────────────────
            if ui=="menu":
                main_menu(self.screen,self.fonts,mx,my)
            elif ui=="scores":
                scores_screen(self.screen,self.fonts)
            elif ui=="help":
                help_screen(self.screen,self.fonts,help_page,mx,my)
            elif ui=="classselect":
                class_select_screen(self.screen,self.fonts,cls_sel,mx,my)
            elif ui=="nameentry" and pending_score:
                sc2,cls2,fl,kl=pending_score
                name_entry_screen(self.screen,self.fonts,sc2,cls2,fl,kl,name_buf)
            elif ui in("dead","victory"):
                self.draw(); self.draw_overlay()
            elif ui=="playing":
                if self.state=="playing":
                    self.inv_ui.handle_mouse(mx,my,self.player,
                                             self.enemies if hasattr(self,'enemies') else [],
                                             self.fov if hasattr(self,'fov') else [])
                    self.shop_ui.handle_mouse(mx,my)
                self.draw()

            pygame.display.flip()
            await asyncio.sleep(0)

async def main():
    if not os.path.exists(SPRITE_DIR):
        print("HUOM: Spritekansio puuttuu. Aja: python generate_sprites.py")
    game=Game()
    await game.run()

if __name__=="__main__":
    asyncio.run(main())