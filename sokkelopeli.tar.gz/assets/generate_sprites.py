"""
Dungeon Crawler - Sprite Generator
Luo kaikki pelin spritet pikseligrafiikalla (32x32px).
Aja: python generate_sprites.py
"""

import pygame
import os

pygame.init()
TILE = 32
OUT = "sprites"
os.makedirs(OUT, exist_ok=True)

def save(surface, name):
    pygame.image.save(surface, f"{OUT}/{name}.png")
    print(f"  ✓ {name}.png")

def new(bg=None):
    s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    if bg:
        s.fill(bg)
    return s

# ─────────────────────────────────────────
#  TAUSTATIILET
# ─────────────────────────────────────────

def make_floor():
    s = new((55, 48, 42))
    # Kivilaatan raidat
    pygame.draw.rect(s, (45, 38, 33), (0, 0, TILE, 1))
    pygame.draw.rect(s, (45, 38, 33), (0, 0, 1, TILE))
    pygame.draw.rect(s, (70, 60, 52), (4, 4, 10, 10))
    pygame.draw.rect(s, (65, 55, 47), (16, 14, 12, 10))
    pygame.draw.rect(s, (60, 52, 44), (6, 18, 8, 8))
    # Pienet naarmut
    pygame.draw.line(s, (40, 33, 28), (20, 6), (26, 10), 1)
    pygame.draw.line(s, (40, 33, 28), (8, 22), (12, 26), 1)
    return s

def make_wall():
    s = new((60, 52, 44))
    # Tiilimäinen rakenne
    for row in range(4):
        y = row * 8
        offset = 8 if row % 2 else 0
        for col in range(5):
            x = col * 8 - offset
            pygame.draw.rect(s, (80, 68, 56), (x + 1, y + 1, 7, 6))
            pygame.draw.rect(s, (45, 38, 32), (x, y, 8, 7), 1)
    # Varjostus ylhäällä
    pygame.draw.rect(s, (30, 25, 20), (0, 0, TILE, 3))
    return s

def make_wall_dark():
    s = make_wall()
    dark = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    dark.fill((0, 0, 0, 100))
    s.blit(dark, (0, 0))
    return s

def make_floor_dark():
    s = make_floor()
    dark = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    dark.fill((0, 0, 0, 140))
    s.blit(dark, (0, 0))
    return s

def make_stairs():
    s = new((55, 48, 42))
    # Portaat
    colors = [(100, 160, 100), (80, 140, 80), (60, 120, 60), (45, 95, 45)]
    widths = [28, 22, 16, 10]
    for i, (c, w) in enumerate(zip(colors, widths)):
        x = (TILE - w) // 2
        y = 4 + i * 6
        pygame.draw.rect(s, c, (x, y, w, 5))
        pygame.draw.rect(s, (30, 80, 30), (x, y, w, 1))
    # Kultainen hehku
    glow = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    pygame.draw.circle(glow, (255, 215, 0, 40), (TILE//2, TILE//2), 12)
    s.blit(glow, (0, 0))
    return s

# ─────────────────────────────────────────
#  PELAAJA
# ─────────────────────────────────────────

def make_player():
    """Soturi - raskaasti panssaroitu ritari."""
    s = new()
    # Leveä teräksinen haarniska
    pygame.draw.rect(s, (140,145,155), (9,11,14,14), border_radius=2)
    pygame.draw.rect(s, (110,115,125), (9,11,14,3))
    pygame.draw.rect(s, (165,170,180), (10,12,12,5))
    # Hartialevyt
    pygame.draw.rect(s, (120,125,135), (6,11,5,5), border_radius=1)
    pygame.draw.rect(s, (120,125,135), (21,11,5,5), border_radius=1)
    pygame.draw.rect(s, (90,95,105),   (6,11,5,5),1,border_radius=1)
    pygame.draw.rect(s, (90,95,105),   (21,11,5,5),1,border_radius=1)
    # Punainen viitta
    pygame.draw.polygon(s, (140,25,25), [(10,14),(9,30),(16,32),(23,30),(22,14)])
    pygame.draw.polygon(s, (100,15,15), [(10,14),(9,30),(11,30),(12,14)])
    # Kypärä täyskypärä
    pygame.draw.circle(s, (130,135,145), (16,8), 6)
    pygame.draw.rect(s,  (110,115,125), (10,8,12,4))
    pygame.draw.rect(s,  (90,95,105),   (10,8,12,4),1)
    # Visor - keltaoranssi hohto
    pygame.draw.rect(s, (255,180,30),  (12,7,8,3))
    pygame.draw.rect(s, (255,220,80),  (13,7,6,2))
    # Miekka - oikeassa kädessä
    pygame.draw.line(s, (190,195,210), (25,8),(29,2), 2)
    pygame.draw.line(s, (220,225,240), (25,8),(29,2), 1)
    pygame.draw.rect(s, (180,145,30),  (23,9,4,2))
    pygame.draw.circle(s,(160,130,30), (24,11),2)
    # Kilpi - vasemmassa
    pygame.draw.rect(s,  (100,80,160), (3,12,6,9),  border_radius=2)
    pygame.draw.rect(s,  (130,105,200),(4,13,4,5),  border_radius=1)
    pygame.draw.circle(s,(200,170,255),(6,17),1)
    # Jalat - raskaat suojalevyt
    pygame.draw.rect(s, (120,125,135), (10,24,5,7))
    pygame.draw.rect(s, (120,125,135), (17,24,5,7))
    pygame.draw.rect(s, (90,95,105),   (9,29,6,3))
    pygame.draw.rect(s, (90,95,105),   (17,29,6,3))
    return s

def make_player_magi():
    """Magi - pitkässä taikaviitassa, sauva kädessä."""
    s = new()
    # Tummansininen pitkä viitta
    pygame.draw.polygon(s, (25,20,80), [
        (16,6),(21,10),(23,31),(16,32),(9,31),(11,10)
    ])
    # Viitta yksityiskohta - tähtikirjailut
    for (sx2,sy2) in [(12,16),(18,20),(13,24),(20,14)]:
        pygame.draw.circle(s,(120,100,220),   (sx2,sy2),1)
        pygame.draw.circle(s,(180,160,255),   (sx2,sy2),1)
    # Valkoinen sisäpaita
    pygame.draw.rect(s, (220,215,235), (13,10,6,8))
    pygame.draw.line(s, (180,175,200), (16,10),(16,18),1)
    # Pää
    pygame.draw.circle(s, (215,175,140), (16,8), 5)
    # Terävä taikurinhuppu
    pygame.draw.polygon(s, (20,15,70), [(16,0),(10,8),(22,8)])
    pygame.draw.polygon(s, (40,30,110),[(16,1),(11,8),(21,8)])
    # Tähti hatun kärjessä
    pygame.draw.circle(s,(200,160,255),(16,2),2)
    pygame.draw.circle(s,(240,210,255),(16,2),1)
    # Silmät - violetit
    pygame.draw.circle(s,(180,100,255),(13,8),2)
    pygame.draw.circle(s,(180,100,255),(19,8),2)
    pygame.draw.circle(s,(220,170,255),(13,8),1)
    pygame.draw.circle(s,(220,170,255),(19,8),1)
    # Sauva - hohtava kristallinpää
    pygame.draw.line(s,  (140,110,60),  (25,9),(29,27),2)
    pygame.draw.circle(s,(80,200,255),  (25,8),4)
    pygame.draw.circle(s,(160,230,255), (25,8),3)
    pygame.draw.circle(s,(230,245,255), (25,8),1)
    # Hohtava aura sauvan ympärillä
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.circle(aura,(60,180,255,50),(25,8),7)
    s.blit(aura,(0,0))
    # Jalat - viitan alta
    pygame.draw.rect(s,(18,14,60),(12,28,4,5))
    pygame.draw.rect(s,(18,14,60),(17,28,4,5))
    return s

def make_player_varas():
    """Varas - nopea, tumma nahkahaarniska, kaksi tikaria."""
    s = new()
    # Musta nahkahaarniska
    pygame.draw.polygon(s, (22,18,28), [
        (16,6),(21,10),(22,28),(16,30),(10,28),(11,10)
    ])
    # Nahkan saumoja
    pygame.draw.line(s,(40,32,48),(16,10),(16,28),1)
    pygame.draw.line(s,(40,32,48),(11,15),(21,15),1)
    pygame.draw.line(s,(40,32,48),(11,20),(21,20),1)
    # Kyynärsuojat - tummanvihreä
    pygame.draw.rect(s,(30,60,30),(7,14,5,6),border_radius=1)
    pygame.draw.rect(s,(22,45,22),(7,14,5,6),1,border_radius=1)
    pygame.draw.rect(s,(30,60,30),(20,14,5,6),border_radius=1)
    pygame.draw.rect(s,(22,45,22),(20,14,5,6),1,border_radius=1)
    # Pää
    pygame.draw.circle(s,(200,165,130),(16,8),5)
    # Huppu peittää kasvot puoliksi
    pygame.draw.polygon(s,(18,14,24),[(10,5),(22,5),(22,9),(16,11),(10,9)])
    pygame.draw.polygon(s,(28,22,34),[(10,5),(22,5),(21,7),(11,7)])
    # Silmä-alue - vain kapeaa viilua
    pygame.draw.rect(s,(200,165,130),(12,8,8,3))
    # Silmät - vihreitä
    pygame.draw.circle(s,(40,220,80),(13,9),1)
    pygame.draw.circle(s,(40,220,80),(19,9),1)
    pygame.draw.circle(s,(120,255,150),(13,9),1)
    pygame.draw.circle(s,(120,255,150),(19,9),1)
    # Kaksi tikaria - ristissä selässä
    pygame.draw.line(s,(190,195,210),(24,8),(29,3),2)
    pygame.draw.line(s,(190,195,210),(29,8),(24,3),2)
    pygame.draw.rect(s,(120,100,40),(23,9,3,2))
    pygame.draw.rect(s,(120,100,40),(26,9,3,2))
    # Vyö - metallisoljet
    pygame.draw.rect(s,(50,42,58),(11,21,10,3))
    pygame.draw.rect(s,(160,140,50),(14,21,4,3))
    pygame.draw.circle(s,(200,180,60),(16,22),1)
    # Jalat - lithe, nopeat
    pygame.draw.rect(s,(25,20,32),(11,24,4,8))
    pygame.draw.rect(s,(25,20,32),(17,24,4,8))
    pygame.draw.rect(s,(40,35,50),(10,30,5,2))
    pygame.draw.rect(s,(40,35,50),(17,30,5,2))
    return s

# ─────────────────────────────────────────
#  VIHOLLISET
# ─────────────────────────────────────────

def make_goblin():
    s = new()
    # Keho - vihreä nahka
    pygame.draw.ellipse(s, (50, 140, 50), (10, 12, 12, 14))
    # Pää
    pygame.draw.circle(s, (60, 160, 60), (16, 9), 7)
    # Isot korvat
    pygame.draw.ellipse(s, (50, 130, 50), (5, 6, 6, 4))
    pygame.draw.ellipse(s, (50, 130, 50), (21, 6, 6, 4))
    # Silmät - punaiset
    pygame.draw.circle(s, (220, 50, 50), (13, 8), 2)
    pygame.draw.circle(s, (220, 50, 50), (19, 8), 2)
    pygame.draw.circle(s, (255, 80, 80), (13, 8), 1)
    pygame.draw.circle(s, (255, 80, 80), (19, 8), 1)
    # Suu - hampaat
    pygame.draw.rect(s, (180, 40, 40), (13, 12, 6, 2))
    pygame.draw.line(s, (255, 240, 220), (14, 12), (14, 14), 1)
    pygame.draw.line(s, (255, 240, 220), (16, 12), (16, 14), 1)
    pygame.draw.line(s, (255, 240, 220), (18, 12), (18, 14), 1)
    # Nuija
    pygame.draw.line(s, (100, 70, 40), (22, 10), (27, 6), 2)
    pygame.draw.circle(s, (80, 55, 30), (27, 5), 3)
    # Jalat
    pygame.draw.rect(s, (40, 110, 40), (11, 25, 4, 6))
    pygame.draw.rect(s, (40, 110, 40), (17, 25, 4, 6))
    return s

def make_orc():
    s = new()
    # Iso keho - tummanvihreä
    pygame.draw.ellipse(s, (100, 80, 30), (7, 13, 18, 16))
    # Haarniska palat
    pygame.draw.rect(s, (80, 75, 70), (9, 14, 14, 10))
    pygame.draw.rect(s, (60, 55, 50), (9, 14, 14, 2))
    # Iso pää
    pygame.draw.circle(s, (120, 100, 40), (16, 9), 7)
    # Töyhtö / kypärä
    pygame.draw.arc(s, (60, 55, 50), (9, 2, 14, 12), 0, 3.14, 5)
    pygame.draw.rect(s, (150, 30, 30), (15, 2, 3, 5))  # Töyhtö
    # Silmät
    pygame.draw.circle(s, (255, 150, 0), (13, 8), 2)
    pygame.draw.circle(s, (255, 150, 0), (19, 8), 2)
    pygame.draw.circle(s, (50, 30, 0), (13, 8), 1)
    pygame.draw.circle(s, (50, 30, 0), (19, 8), 1)
    # Kiilat / hampaat
    pygame.draw.polygon(s, (230, 210, 180), [(14, 14), (13, 17), (15, 14)])
    pygame.draw.polygon(s, (230, 210, 180), [(18, 14), (19, 17), (17, 14)])
    # Kirvessä
    pygame.draw.line(s, (120, 90, 50), (22, 8), (26, 16), 2)
    pygame.draw.polygon(s, (160, 155, 150), [(24, 6), (28, 10), (26, 16), (22, 12)])
    # Jalat
    pygame.draw.rect(s, (80, 65, 25), (10, 28, 5, 5))
    pygame.draw.rect(s, (80, 65, 25), (17, 28, 5, 5))
    pygame.draw.rect(s, (60, 45, 15), (9, 31, 6, 3))
    pygame.draw.rect(s, (60, 45, 15), (17, 31, 6, 3))
    return s

def make_troll():
    s = new()
    # Iso keho - harmaa/vihreä
    pygame.draw.ellipse(s, (80, 110, 60), (5, 11, 22, 19))
    # Ihon tekstuuri
    pygame.draw.ellipse(s, (70, 100, 50), (7, 13, 8, 8))
    pygame.draw.ellipse(s, (70, 100, 50), (17, 15, 7, 7))
    # Iso pää
    pygame.draw.circle(s, (90, 120, 70), (16, 8), 8)
    # Pienehköt silmät
    pygame.draw.circle(s, (255, 80, 0), (12, 7), 2)
    pygame.draw.circle(s, (255, 80, 0), (20, 7), 2)
    pygame.draw.circle(s, (150, 30, 0), (12, 7), 1)
    pygame.draw.circle(s, (150, 30, 0), (20, 7), 1)
    # Nenä
    pygame.draw.ellipse(s, (70, 100, 50), (14, 9, 4, 3))
    # Suu / hampaat
    pygame.draw.rect(s, (50, 30, 20), (11, 13, 10, 3))
    for i in range(4):
        pygame.draw.rect(s, (230, 220, 200), (12 + i*2, 13, 1, 2))
    # Kädet
    pygame.draw.ellipse(s, (80, 110, 60), (2, 15, 6, 4))
    pygame.draw.ellipse(s, (80, 110, 60), (24, 15, 6, 4))
    # Kynnet
    pygame.draw.line(s, (50, 70, 40), (2, 17), (1, 20), 1)
    pygame.draw.line(s, (50, 70, 40), (7, 17), (8, 20), 1)
    pygame.draw.line(s, (50, 70, 40), (25, 17), (24, 20), 1)
    pygame.draw.line(s, (50, 70, 40), (29, 17), (30, 20), 1)
    # Jalat
    pygame.draw.rect(s, (70, 100, 50), (9, 28, 6, 5))
    pygame.draw.rect(s, (70, 100, 50), (17, 28, 6, 5))
    return s

def make_skeleton():
    s = new()
    # Luuranko - luun väri
    BONE = (210, 200, 185)
    DARK_BONE = (160, 150, 135)
    # Keho / ribcage
    for i in range(4):
        y = 14 + i * 3
        pygame.draw.arc(s, BONE, (10, y, 12, 4), 0, 3.14, 2)
    # Selkäranka
    for i in range(5):
        pygame.draw.rect(s, BONE, (15, 12 + i * 3, 2, 2))
    # Pää - kallo
    pygame.draw.ellipse(s, BONE, (10, 2, 12, 11))
    # Silmäkuopat
    pygame.draw.ellipse(s, (20, 15, 10), (11, 5, 4, 4))
    pygame.draw.ellipse(s, (20, 15, 10), (17, 5, 4, 4))
    pygame.draw.ellipse(s, (50, 40, 30), (12, 6, 3, 3))
    pygame.draw.ellipse(s, (50, 40, 30), (18, 6, 3, 3))
    # Nenäreikä
    pygame.draw.rect(s, (20, 15, 10), (15, 10, 2, 2))
    # Hampaat
    for i in range(4):
        pygame.draw.rect(s, BONE, (11 + i*2, 12, 1, 2))
    # Käsivarret - luiset
    pygame.draw.line(s, BONE, (10, 14), (4, 20), 2)
    pygame.draw.line(s, BONE, (22, 14), (27, 20), 2)
    # Miekka
    pygame.draw.line(s, (170, 170, 180), (26, 18), (30, 8), 2)
    pygame.draw.rect(s, DARK_BONE, (24, 19, 5, 2))
    # Jalat
    pygame.draw.line(s, BONE, (14, 27), (12, 32), 2)
    pygame.draw.line(s, BONE, (18, 27), (20, 32), 2)
    # Jalkaterät
    pygame.draw.rect(s, BONE, (10, 30, 5, 2))
    pygame.draw.rect(s, BONE, (18, 30, 5, 2))
    return s

def make_wizard():
    s = new()
    # Pitkä viitta - tummansininen
    pygame.draw.polygon(s, (40, 30, 120), [
        (16, 6), (22, 12), (24, 30), (16, 32), (8, 30), (10, 12)
    ])
    # Tähdet viitassa
    pygame.draw.circle(s, (200, 180, 50), (12, 18), 1)
    pygame.draw.circle(s, (200, 180, 50), (20, 22), 1)
    pygame.draw.circle(s, (200, 180, 50), (14, 26), 1)
    # Pää
    pygame.draw.circle(s, (190, 155, 120), (16, 7), 5)
    # Hattu - spiteesi suippo
    pygame.draw.polygon(s, (30, 20, 100), [
        (16, 0), (10, 8), (22, 8)
    ])
    pygame.draw.rect(s, (30, 20, 100), (9, 7, 14, 3))
    pygame.draw.rect(s, (60, 50, 150), (9, 7, 14, 1))
    # Silmät - hohtavat
    pygame.draw.circle(s, (130, 200, 255), (14, 7), 2)
    pygame.draw.circle(s, (130, 200, 255), (18, 7), 2)
    pygame.draw.circle(s, (255, 255, 255), (14, 7), 1)
    pygame.draw.circle(s, (255, 255, 255), (18, 7), 1)
    # Sauva
    pygame.draw.line(s, (100, 80, 40), (24, 10), (28, 28), 2)
    # Hohtava kristalli
    pygame.draw.circle(s, (100, 200, 255), (28, 9), 3)
    pygame.draw.circle(s, (200, 240, 255), (28, 9), 1)
    # Parta
    pygame.draw.ellipse(s, (210, 200, 195), (13, 10, 6, 5))
    return s

# ─────────────────────────────────────────
#  ESINEET
# ─────────────────────────────────────────

def make_health_potion():
    s = new()
    # Pullo
    pygame.draw.rect(s, (180, 50, 50), (13, 10, 6, 12))
    pygame.draw.ellipse(s, (180, 50, 50), (11, 16, 10, 8))
    # Pullonkaula
    pygame.draw.rect(s, (150, 40, 40), (14, 6, 4, 6))
    pygame.draw.rect(s, (120, 30, 30), (13, 5, 6, 3))
    # Korkkki
    pygame.draw.rect(s, (140, 100, 40), (14, 3, 4, 4))
    # Hohto
    pygame.draw.ellipse(s, (255, 100, 100, 180), (12, 11, 4, 6))
    pygame.draw.ellipse(s, (255, 150, 150, 120), (11, 10, 10, 10))
    # Kiilto
    pygame.draw.ellipse(s, (255, 200, 200), (14, 12, 2, 4))
    return s

def make_gold():
    s = new()
    # Kolikkokasa
    for i, (x, y, r) in enumerate([(14, 22, 5), (18, 20, 5), (16, 18, 5),
                                     (12, 20, 4), (16, 16, 4)]):
        shade = (220 - i*10, 185 - i*8, 20 - i*2)
        pygame.draw.circle(s, shade, (x, y), r)
        pygame.draw.circle(s, (240, 210, 50), (x, y), r - 1)
        pygame.draw.circle(s, (255, 230, 80), (x - 1, y - 1), 1)
    # Sparkle-efekti
    pygame.draw.line(s, (255, 255, 150), (10, 10), (12, 12), 1)
    pygame.draw.line(s, (255, 255, 150), (22, 8), (20, 10), 1)
    pygame.draw.circle(s, (255, 255, 200), (9, 9), 1)
    pygame.draw.circle(s, (255, 255, 200), (23, 7), 1)
    return s

def make_sword():
    s = new()
    # Terä
    pygame.draw.polygon(s, (200, 205, 215), [
        (24, 4), (26, 6), (10, 26), (8, 24)
    ])
    pygame.draw.line(s, (230, 235, 245), (24, 4), (9, 25), 1)
    # Kädensija
    pygame.draw.rect(s, (150, 100, 30), (7, 23, 2, 6))
    # Kahvan suoja
    pygame.draw.rect(s, (180, 150, 40), (4, 22, 8, 3))
    # Kahvan pää
    pygame.draw.circle(s, (160, 120, 30), (8, 28), 2)
    # Hohto
    pygame.draw.circle(s, (255, 255, 200), (23, 5), 1)
    pygame.draw.line(s, (220, 220, 230), (26, 4), (28, 2), 1)
    pygame.draw.line(s, (220, 220, 230), (26, 4), (28, 6), 1)
    return s

def make_shield():
    s = new()
    # Kilven pohja
    pygame.draw.polygon(s, (50, 80, 160), [
        (16, 5), (25, 10), (25, 22), (16, 28), (7, 22), (7, 10)
    ])
    # Kilven reunus
    pygame.draw.polygon(s, (40, 60, 130), [
        (16, 5), (25, 10), (25, 22), (16, 28), (7, 22), (7, 10)
    ], 2)
    # Kruunu kuvio
    pygame.draw.polygon(s, (200, 170, 40), [
        (16, 10), (19, 14), (22, 13), (20, 17), (16, 16), (12, 17), (10, 13), (13, 14)
    ])
    # Kiilto
    pygame.draw.line(s, (100, 140, 220), (10, 9), (10, 20), 2)
    pygame.draw.line(s, (150, 180, 240), (11, 8), (11, 12), 1)
    return s

def make_xp_gem():
    s = new()
    # Jalokivi - oktaedri muoto
    pygame.draw.polygon(s, (180, 50, 220), [
        (16, 5), (24, 14), (20, 26), (16, 28), (12, 26), (8, 14)
    ])
    pygame.draw.polygon(s, (200, 80, 240), [
        (16, 5), (24, 14), (16, 16)
    ])
    pygame.draw.polygon(s, (140, 30, 180), [
        (8, 14), (16, 16), (16, 28), (12, 26)
    ])
    # Hohto
    pygame.draw.polygon(s, (230, 150, 255), [
        (16, 5), (24, 14), (16, 16)
    ], 1)
    # Kiilto
    pygame.draw.line(s, (255, 220, 255), (14, 8), (12, 12), 1)
    pygame.draw.circle(s, (255, 255, 255), (19, 10), 1)
    # Sparklet
    pygame.draw.circle(s, (220, 150, 255), (8, 8), 1)
    pygame.draw.circle(s, (220, 150, 255), (24, 22), 1)
    pygame.draw.line(s, (220, 150, 255), (7, 6), (7, 10), 1)
    pygame.draw.line(s, (220, 150, 255), (5, 8), (9, 8), 1)
    return s

# ─────────────────────────────────────────
#  UI / EFEKTIT
# ─────────────────────────────────────────

def make_fog():
    s = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    s.fill((15, 12, 20, 200))
    return s

def make_cursor():
    s = new()
    pygame.draw.rect(s, (255, 255, 100, 180), (1, 1, TILE-2, TILE-2), 2)
    return s

def make_spider():
    s = new()
    # Vartalo - tummanvioletti, kiiltävä
    pygame.draw.ellipse(s, (80, 20, 120), (10, 12, 12, 10))   # takaruumis
    pygame.draw.ellipse(s, (100, 30, 150), (12, 10, 8, 8))    # eturuumis
    # Kiilto takaruumiissa
    pygame.draw.ellipse(s, (140, 60, 190), (11, 13, 5, 4))
    pygame.draw.ellipse(s, (200, 120, 240), (12, 13, 2, 2))   # kirkas kiilto
    # 8 jalkaa - neljä per puoli, nivelletty
    leg_cols = [(90, 30, 130), (110, 40, 160)]
    legs_left  = [(9,13,6,10), (7,14,5,17), (7,16,5,20), (9,18,7,22)]
    legs_right = [(23,13,26,10),(25,14,27,17),(25,16,27,20),(23,18,25,22)]
    for i, ((x1,y1,x2,y2), (x3,y3,x4,y4)) in enumerate(zip(legs_left, legs_right)):
        c = leg_cols[i % 2]
        pygame.draw.line(s, c, (x1,y1), (x2,y2), 2)
        pygame.draw.line(s, c, (x3,y3), (x4,y4), 2)
        # Nivelpiste
        pygame.draw.circle(s, (60, 10, 90), (x2, y2), 1)
        pygame.draw.circle(s, (60, 10, 90), (x4, y4), 1)
    # Silmät - 6 pientä punaisesti hohtavaa
    eye_pos = [(12,10),(14,9),(16,9),(18,10),(14,11),(16,11)]
    for i,(ex,ey) in enumerate(eye_pos):
        pygame.draw.circle(s, (220, 20, 20), (ex,ey), 1)
        if i < 2:  # isoimmat silmät hohtavat
            pygame.draw.circle(s, (255, 100, 100), (ex,ey), 1)
    # Myrkkypisarat hampailta
    pygame.draw.circle(s, (80, 220, 80), (15, 14), 1)
    pygame.draw.circle(s, (60, 200, 60), (17, 15), 1)
    # Myrkkyväri-aura
    aura = pygame.Surface((TILE, TILE), pygame.SRCALPHA)
    pygame.draw.ellipse(aura, (60, 180, 60, 35), (8, 8, 16, 16))
    s.blit(aura, (0, 0))
    return s

def make_vampire():
    s = new()
    # Musta viitta
    pygame.draw.polygon(s, (20, 15, 35), [
        (16,5),(23,10),(25,30),(16,32),(7,30),(9,10)
    ])
    pygame.draw.polygon(s, (40,25,60), [
        (16,5),(23,10),(22,12),(16,8),(10,12),(9,10)
    ])
    # Kaulus punaisena
    pygame.draw.polygon(s, (160,20,20), [(12,10),(20,10),(22,14),(10,14)])
    # Pää
    pygame.draw.circle(s, (195,160,145), (16,8), 5)
    # Silmät - punaiset
    pygame.draw.circle(s, (220,30,30), (14,7), 2)
    pygame.draw.circle(s, (220,30,30), (18,7), 2)
    pygame.draw.circle(s, (255,80,80),  (14,7), 1)
    pygame.draw.circle(s, (255,80,80),  (18,7), 1)
    # Hiukset
    pygame.draw.arc(s, (20,15,30), (11,3,10,8), 0, 3.14, 4)
    # Kulmakarvat V-muoto
    pygame.draw.line(s, (20,15,30), (12,5),(14,7), 1)
    pygame.draw.line(s, (20,15,30), (20,5),(18,7), 1)
    # Hampaat
    pygame.draw.polygon(s, (240,235,225), [(14,12),(15,14),(16,12)])
    pygame.draw.polygon(s, (240,235,225), [(17,12),(18,14),(19,12)])
    # Kädet viitan sisästä
    pygame.draw.ellipse(s, (195,160,145), (5,15,5,4))
    pygame.draw.ellipse(s, (195,160,145), (22,15,5,4))
    # Kynnet
    pygame.draw.line(s, (80,20,80),(5,17),(3,20),1)
    pygame.draw.line(s, (80,20,80),(9,17),(10,20),1)
    pygame.draw.line(s, (80,20,80),(22,17),(21,20),1)
    pygame.draw.line(s, (80,20,80),(26,17),(27,20),1)
    # Lepakko-siipivihje
    pygame.draw.line(s, (30,20,50),(7,14),(3,10),2)
    pygame.draw.line(s, (30,20,50),(25,14),(29,10),2)
    return s

def make_demon():
    s = new()
    # Punainen vartalo
    pygame.draw.ellipse(s, (180,30,30), (8,12,16,16))
    # Siivet
    pygame.draw.polygon(s, (120,15,15), [(8,14),(2,8),(6,18)])
    pygame.draw.polygon(s, (120,15,15), [(24,14),(30,8),(26,18)])
    pygame.draw.polygon(s, (150,20,20), [(8,14),(2,8),(5,12)])
    pygame.draw.polygon(s, (150,20,20), [(24,14),(30,8),(27,12)])
    # Pää
    pygame.draw.circle(s, (200,40,40),(16,8),6)
    # Sarvet
    pygame.draw.polygon(s, (80,15,15),  [(12,4),(10,0),(14,6)])
    pygame.draw.polygon(s, (80,15,15),  [(20,4),(22,0),(18,6)])
    pygame.draw.polygon(s, (100,20,20), [(12,4),(11,1),(14,6)])
    pygame.draw.polygon(s, (100,20,20), [(20,4),(21,1),(18,6)])
    # Silmät - keltaiset
    pygame.draw.circle(s, (255,200,0),(13,8),2)
    pygame.draw.circle(s, (255,200,0),(19,8),2)
    pygame.draw.circle(s, (200,100,0),(13,8),1)
    pygame.draw.circle(s, (200,100,0),(19,8),1)
    # Suu - hampainen
    for i in range(5):
        pygame.draw.line(s,(30,10,10),(13+i*2,12),(13+i*2,14),1)
    # Häntä
    pygame.draw.line(s,(150,25,25),(16,28),(20,32),2)
    pygame.draw.polygon(s,(120,15,15),[(18,30),(22,32),(20,28)])
    # Jalat
    pygame.draw.rect(s,(160,28,28),(11,27,5,6))
    pygame.draw.rect(s,(160,28,28),(16,27,5,6))
    pygame.draw.rect(s,(80,15,15),(10,31,5,2))
    pygame.draw.rect(s,(80,15,15),(17,31,5,2))
    return s

def make_golem():
    s = new()
    # Kivinen vartalo - harmaa
    pygame.draw.rect(s, (100,95,90),(8,10,16,18), border_radius=3)
    # Kivirakenne viivat
    pygame.draw.line(s,(70,65,60),(8,16),(24,16),1)
    pygame.draw.line(s,(70,65,60),(8,22),(24,22),1)
    pygame.draw.line(s,(70,65,60),(16,10),(16,28),1)
    # Pää - iso neliö
    pygame.draw.rect(s,(110,105,100),(9,3,14,10), border_radius=2)
    pygame.draw.rect(s,(80,75,70),(9,3,14,10),1,border_radius=2)
    # Hehkuvat silmät - vihreät
    pygame.draw.rect(s,(0,200,80),(11,6,4,3), border_radius=1)
    pygame.draw.rect(s,(0,200,80),(17,6,4,3), border_radius=1)
    pygame.draw.rect(s,(120,255,150),(12,7,2,1))
    pygame.draw.rect(s,(120,255,150),(18,7,2,1))
    # Massiiviset kädet
    pygame.draw.rect(s,(95,90,85),(3,11,6,10), border_radius=2)
    pygame.draw.rect(s,(95,90,85),(23,11,6,10), border_radius=2)
    # Nyrkit
    pygame.draw.rect(s,(85,80,75),(2,20,7,6), border_radius=2)
    pygame.draw.rect(s,(85,80,75),(23,20,7,6), border_radius=2)
    # Raot/halkeamat
    pygame.draw.line(s,(50,45,40),(10,11),(13,15),1)
    pygame.draw.line(s,(50,45,40),(18,19),(21,24),1)
    # Jalat
    pygame.draw.rect(s,(90,85,80),(9,27,6,5))
    pygame.draw.rect(s,(90,85,80),(17,27,6,5))
    return s

def make_necromancer():
    s = new()
    # Musta kaapumaiset vaatteet
    pygame.draw.polygon(s,(15,10,25),[
        (16,5),(22,11),(24,30),(16,32),(8,30),(10,11)
    ])
    # Luurankokuosikirjailua
    pygame.draw.circle(s,(60,55,70),(12,18),2)
    pygame.draw.circle(s,(60,55,70),(20,22),2)
    pygame.draw.circle(s,(60,55,70),(14,26),1)
    # Pää - kallomainen
    pygame.draw.ellipse(s,(185,175,160),(10,2,12,11))
    # Silmäkuopat - hehkuvat vihreät
    pygame.draw.ellipse(s,(0,0,0),(11,5,4,4))
    pygame.draw.ellipse(s,(0,0,0),(17,5,4,4))
    pygame.draw.ellipse(s,(0,180,60),(12,6,3,3))
    pygame.draw.ellipse(s,(0,180,60),(18,6,3,3))
    pygame.draw.circle(s,(100,255,150),(13,7),1)
    pygame.draw.circle(s,(100,255,150),(19,7),1)
    # Nenäreikä
    pygame.draw.rect(s,(0,0,0),(15,10,2,2))
    # Sauva luurangonpää
    pygame.draw.line(s,(100,85,60),(24,10),(28,26),2)
    pygame.draw.circle(s,(185,175,160),(28,9),4)
    pygame.draw.circle(s,(0,0,0),(27,8),2)
    pygame.draw.circle(s,(0,200,80),(27,8),1)
    pygame.draw.line(s,(100,85,60),(25,7),(31,7),1)
    pygame.draw.line(s,(100,85,60),(28,4),(28,10),1)
    # Hehku
    glow = pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.circle(glow,(0,150,60,40),(28,9),6)
    s.blit(glow,(0,0))
    return s

def make_wraith():
    s = new()
    # Haamun keho - puolihäipyvä
    body = pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(body,(100,80,180,160),(8,8,16,20))
    # Häntämäinen alapää
    pygame.draw.polygon(body,(80,60,160,120),[
        (10,22),(16,32),(22,22),(20,28),(16,30),(12,28)
    ])
    s.blit(body,(0,0))
    # Kasvot - haalistuneet
    pygame.draw.ellipse(s,(140,120,200,200),(10,10,12,10))
    # Silmät - tyhjät kuopat
    pygame.draw.ellipse(s,(20,10,40),(12,12,3,4))
    pygame.draw.ellipse(s,(20,10,40),(17,12,3,4))
    pygame.draw.ellipse(s,(180,150,255),(12,12,3,4))
    pygame.draw.ellipse(s,(180,150,255),(17,12,3,4))
    pygame.draw.circle(s,(255,230,255),(13,14),1)
    pygame.draw.circle(s,(255,230,255),(18,14),1)
    # Kät - läpinäkyvät
    arm = pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.line(arm,(120,100,200,150),(8,14),(3,20),2)
    pygame.draw.line(arm,(120,100,200,150),(24,14),(29,20),2)
    # Sormenpäät
    pygame.draw.circle(arm,(160,130,220,140),(3,20),2)
    pygame.draw.circle(arm,(160,130,220,140),(29,20),2)
    s.blit(arm,(0,0))
    # Hohtava aura
    aura = pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(120,80,220,30),(4,6,24,24))
    pygame.draw.ellipse(aura,(160,120,255,20),(2,4,28,28))
    s.blit(aura,(0,0))
    return s

# ─────────────────────────────────────────
#  BOSSIT
# ─────────────────────────────────────────

def make_boss_varjolord():
    """Kerros 5 – Varjolord: varjoprinssi, violetti kaapumaisesti."""
    s = new()
    # Varjokaapukeho
    pygame.draw.polygon(s, (35,10,60), [(16,3),(25,10),(27,32),(16,32),(5,32),(7,10)])
    pygame.draw.polygon(s, (55,20,90), [(16,3),(25,10),(24,12),(16,6),(8,12),(7,10)])
    # Säteilevät varjosiivet
    wing = pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.polygon(wing,(80,0,160,140),[(6,10),(0,2),(4,18)])
    pygame.draw.polygon(wing,(80,0,160,140),[(26,10),(32,2),(28,18)])
    s.blit(wing,(0,0))
    # Pää – kallo violetilla hehkulla
    pygame.draw.ellipse(s,(180,160,200),(10,2,12,11))
    pygame.draw.ellipse(s,(0,0,0),(11,5,4,4))
    pygame.draw.ellipse(s,(0,0,0),(17,5,4,4))
    pygame.draw.ellipse(s,(160,0,255),(12,6,3,3))
    pygame.draw.ellipse(s,(160,0,255),(18,6,3,3))
    pygame.draw.circle(s,(220,150,255),(13,7),1)
    pygame.draw.circle(s,(220,150,255),(19,7),1)
    # Kruunu pimeyden kitkoista
    for i,cx in enumerate([11,14,16,18,21]):
        h = 3 if i%2==0 else 5
        pygame.draw.rect(s,(100,0,180),(cx,0,2,h))
    # Varjoklinge
    pygame.draw.polygon(s,(80,0,160),[(24,8),(30,3),(32,14),(26,16)])
    pygame.draw.polygon(s,(140,60,220),[(25,9),(29,5),(30,12)])
    pygame.draw.line(s,(200,150,255),(24,8),(32,4),1)
    # Hohtava aura
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(120,0,220,45),(4,4,24,24))
    s.blit(aura,(0,0))
    return s

def make_boss_abyssi():
    """Kerros 10 – Abyssin kuningas: tummanpunainen tuhoava olento."""
    s = new()
    # Massiivinen vartalo
    pygame.draw.ellipse(s,(140,0,60),(6,10,20,20))
    pygame.draw.ellipse(s,(180,10,80),(8,12,16,14))
    # Kolme paria siipejä
    for dy,alpha in [(10,160),(14,120),(18,80)]:
        w=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
        pygame.draw.polygon(w,(200,0,60,alpha),[(6,dy),(0,dy-6),(3,dy+5)])
        pygame.draw.polygon(w,(200,0,60,alpha),[(26,dy),(32,dy-6),(29,dy+5)])
        s.blit(w,(0,0))
    # Kolme päätä nebeneinander
    for hx in [9,16,23]:
        pygame.draw.circle(s,(160,0,50),(hx,7),4)
        pygame.draw.circle(s,(220,10,80),(hx,6),3)
        pygame.draw.circle(s,(255,120,0),(hx-1,6),1)
        pygame.draw.circle(s,(255,120,0),(hx+1,6),1)
        pygame.draw.line(s,(80,0,20),(hx-2,10),(hx+2,10),1)
    # Sarvet keski-pään päällä
    pygame.draw.polygon(s,(100,0,30),[(14,2),(12,6),(16,5)])
    pygame.draw.polygon(s,(100,0,30),[(18,2),(20,6),(16,5)])
    # Massiiviset kynnet
    for cx,cy in [(4,28),(28,28)]:
        for dk in [-2,0,2]:
            pygame.draw.line(s,(80,0,20),(cx,cy),(cx+dk,cy+5),2)
    # Häntä
    pygame.draw.line(s,(160,0,50),(16,30),(20,32),3)
    pygame.draw.polygon(s,(120,0,30),[(18,30),(22,32),(20,28)])
    # Aura
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(200,0,60,50),(2,2,28,28))
    s.blit(aura,(0,0))
    return s

def make_boss_ignaras():
    """Kerros 15 – Lohikäärme Ignaras: valtava punainen lohikäärme."""
    s = new()
    # Vartalo – lohikäärme kaareva
    pygame.draw.ellipse(s,(180,50,0),(7,12,18,16))
    pygame.draw.ellipse(s,(220,80,10),(9,14,14,10))
    # Suomut
    for sy2 in range(13,27,3):
        for sx2 in range(8,23,4):
            pygame.draw.ellipse(s,(200,60,5),(sx2,sy2,4,3))
            pygame.draw.ellipse(s,(240,100,20),(sx2+1,sy2,2,2))
    # Iso pää
    pygame.draw.ellipse(s,(190,55,5),(6,2,20,13))
    pygame.draw.ellipse(s,(220,80,10),(7,3,18,10))
    # Suuri tuli silmä
    pygame.draw.circle(s,(255,200,0),(12,7),3)
    pygame.draw.circle(s,(255,100,0),(12,7),2)
    pygame.draw.circle(s,(255,255,0),(12,7),1)
    pygame.draw.circle(s,(255,200,0),(20,7),3)
    pygame.draw.circle(s,(255,100,0),(20,7),2)
    pygame.draw.circle(s,(255,255,0),(20,7),1)
    # Hampaat
    for i in range(6):
        pygame.draw.polygon(s,(240,220,180),[(8+i*3,13),(9+i*3,16),(10+i*3,13)])
    # Siivet
    pygame.draw.polygon(s,(160,40,0),[(7,14),(1,6),(5,20)])
    pygame.draw.polygon(s,(160,40,0),[(25,14),(31,6),(27,20)])
    pygame.draw.polygon(s,(200,65,10),[(7,14),(2,7),(4,14)])
    pygame.draw.polygon(s,(200,65,10),[(25,14),(30,7),(28,14)])
    # Tuliefekti
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(255,100,0,60),(3,3,26,26))
    pygame.draw.circle(aura,(255,200,0,80),(16,7),6)
    s.blit(aura,(0,0))
    # Häntä
    pygame.draw.line(s,(180,50,0),(20,28),(28,32),3)
    pygame.draw.line(s,(160,40,0),(28,32),(30,28),2)
    return s

def make_boss_enkeli():
    """Kerros 20 – Kuolemanenkeli: hopeavalkea enkeli tummilla siivilla."""
    s = new()
    # Valkoinen kehrä
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(255,255,220,55),(2,2,28,28))
    s.blit(aura,(0,0))
    # Mustat siivet
    pygame.draw.polygon(s,(20,15,30),[(8,14),(0,3),(5,22)])
    pygame.draw.polygon(s,(20,15,30),[(24,14),(32,3),(27,22)])
    pygame.draw.polygon(s,(40,30,55),[(8,14),(1,5),(4,14)])
    pygame.draw.polygon(s,(40,30,55),[(24,14),(31,5),(28,14)])
    # Vartalo hopeinen haarniska
    pygame.draw.rect(s,(190,195,210),(10,11,12,16),border_radius=3)
    pygame.draw.rect(s,(220,225,240),(11,12,10,8))
    pygame.draw.rect(s,(160,165,180),(10,11,12,3))
    # Pää – ylväs
    pygame.draw.circle(s,(220,210,200),(16,7),5)
    # Sädekehä
    halo=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(halo,(255,240,100,180),(8,1,16,5))
    pygame.draw.ellipse(halo,(255,255,200,100),(8,0,16,6),2)
    s.blit(halo,(0,0))
    # Silmät mustat
    pygame.draw.circle(s,(10,5,20),(13,7),2)
    pygame.draw.circle(s,(19,14,35),(13,7),1)
    pygame.draw.circle(s,(10,5,20),(19,7),2)
    pygame.draw.circle(s,(19,14,35),(19,7),1)
    # Tuhoava miekka
    pygame.draw.polygon(s,(220,225,240),[(25,3),(28,6),(14,28),(11,25)])
    pygame.draw.line(s,(255,255,255),(25,3),(13,26),1)
    pygame.draw.rect(s,(200,180,50),(22,8,5,2))
    return s

def make_boss_titaani():
    """Kerros 25 – Kaaos Titaani: valtava violetti energiahirviö."""
    s = new()
    # Energia-aura
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(180,0,255,70),(0,0,32,32))
    s.blit(aura,(0,0))
    # Massiivinen kivikeho
    pygame.draw.rect(s,(55,30,80),(5,8,22,22),border_radius=4)
    pygame.draw.rect(s,(80,45,110),(7,10,18,16),border_radius=3)
    # Energia-raot
    pygame.draw.line(s,(200,100,255),(5,14),(27,14),2)
    pygame.draw.line(s,(200,100,255),(5,20),(27,20),2)
    pygame.draw.line(s,(200,100,255),(16,8),(16,30),2)
    # Pää
    pygame.draw.rect(s,(65,35,95),(7,1,18,10),border_radius=3)
    pygame.draw.rect(s,(90,55,120),(8,2,16,7))
    # Hehkuvat silmät
    for ex in [11,21]:
        pygame.draw.circle(s,(180,0,255),(ex,6),3)
        pygame.draw.circle(s,(220,100,255),(ex,6),2)
        pygame.draw.circle(s,(255,200,255),(ex,6),1)
    # Sarvet
    pygame.draw.polygon(s,(120,0,180),[(10,1),(8,0),(11,5)])
    pygame.draw.polygon(s,(120,0,180),[(22,1),(24,0),(21,5)])
    # Massiiviset kädet
    pygame.draw.rect(s,(60,35,90),(0,12,6,12),border_radius=2)
    pygame.draw.rect(s,(60,35,90),(26,12,6,12),border_radius=2)
    # Energia-nyrkit
    pygame.draw.rect(s,(100,0,200),(0,22,7,7),border_radius=2)
    pygame.draw.rect(s,(100,0,200),(25,22,7,7),border_radius=2)
    pygame.draw.circle(s,(200,100,255),(3,25),2)
    pygame.draw.circle(s,(200,100,255),(29,25),2)
    return s

def make_boss_generic(tier):
    """Generoi visuaalinen bossisprite tier-numerolle (1-20)."""
    s = new()
    # Väri skaalautuu tierillä
    r = min(255, 80 + tier*9)
    g = max(0, 100 - tier*5)
    b = min(255, 200 - tier*3)
    col  = (r,g,b)
    col2 = (min(255,r+50), min(255,g+30), min(255,b+50))
    dark = (max(0,r-60), max(0,g-30), max(0,b-60))
    # Aura
    aura=pygame.Surface((TILE,TILE),pygame.SRCALPHA)
    pygame.draw.ellipse(aura,(*col,65),(1,1,30,30))
    s.blit(aura,(0,0))
    # Keho
    pygame.draw.ellipse(s,dark,(6,10,20,20))
    pygame.draw.ellipse(s,col,(8,12,16,14))
    pygame.draw.ellipse(s,col2,(10,14,12,8))
    # Pää
    pygame.draw.circle(s,col,(16,7),7)
    pygame.draw.circle(s,col2,(16,7),5)
    # Silmät
    pygame.draw.circle(s,(255,255,100),(13,6),2)
    pygame.draw.circle(s,(255,255,100),(19,6),2)
    pygame.draw.circle(s,(255,200,0),(13,6),1)
    pygame.draw.circle(s,(255,200,0),(19,6),1)
    # Kruunu
    for cx in [11,14,16,18,21]:
        h=3+(tier%3)
        pygame.draw.rect(s,col2,(cx,0,2,h))
    # Siivet
    pygame.draw.polygon(s,dark,[(6,14),(0,6),(4,22)])
    pygame.draw.polygon(s,dark,[(26,14),(32,6),(28,22)])
    pygame.draw.polygon(s,col,[(7,14),(1,8),(4,16)])
    pygame.draw.polygon(s,col,[(25,14),(31,8),(28,16)])
    # Jalat
    pygame.draw.rect(s,dark,(10,28,5,5))
    pygame.draw.rect(s,dark,(17,28,5,5))
    pygame.draw.rect(s,col,(11,29,4,3))
    pygame.draw.rect(s,col,(18,29,4,3))
    return s



print("🎨 Generoidaan spritet...")

# Taustatiilet
save(make_floor(), "floor")
save(make_floor_dark(), "floor_dark")
save(make_wall(), "wall")
save(make_wall_dark(), "wall_dark")
save(make_stairs(), "stairs")

# Pelaaja (kolme luokkaspriteä)
save(make_player(),       "player_soturi")
save(make_player_magi(),  "player_magi")
save(make_player_varas(), "player_varas")
# Takaperin yhteensopivuus (oletus = soturi)
save(make_player(),       "player")

# Viholliset
save(make_goblin(), "goblin")
save(make_orc(), "orc")
save(make_troll(), "troll")
save(make_skeleton(), "skeleton")
save(make_wizard(), "wizard")
save(make_spider(), "spider")
save(make_vampire(), "vampire")
save(make_demon(), "demon")
save(make_golem(), "golem")
save(make_necromancer(), "necromancer")
save(make_wraith(), "wraith")

# Esineet
save(make_health_potion(), "health")
save(make_gold(), "gold")
save(make_sword(), "sword")
save(make_shield(), "shield")
save(make_xp_gem(), "xp")

# UI
save(make_fog(), "fog")
save(make_cursor(), "cursor")

# Bossit
save(make_boss_varjolord(), "boss_5")
save(make_boss_abyssi(),    "boss_10")
save(make_boss_ignaras(),   "boss_15")
save(make_boss_enkeli(),    "boss_20")
save(make_boss_titaani(),   "boss_25")
# Tasot 30–100: generoidaan dynaamisesti tierillä
for floor in range(30, 101, 5):
    tier = (floor - 30) // 5 + 6  # tier 6–20
    save(make_boss_generic(tier), f"boss_{floor}")

print(f"\n✅ Kaikki {17 + 20} spritea generoitu kansioon '{OUT}/'")
pygame.quit()